package ch.epfl.rechor.gui;

import ch.epfl.rechor.StopIndex;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Bounds;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import javafx.scene.input.KeyEvent;
import javafx.stage.Popup;

import java.util.List;

/**
 * Représente la combinaison d’un champ textuel et d’une fenêtre, qui permet de choisir un arrêt de transport public.
 * Le champ textuel permet de saisir une requête et la fenêtre affiche dynamiquement les 30 meilleurs résultats de recherche d’arrêt,
 * triés par pertinence. Le premier résultat est sélectionné initialement. La sélection se fait par la touche tabulation
 * tandis que les touches ↑ et ↓ permettent le "déplacement" dans la barre de recherche.
 * Lorsque le champ textuel devient inactif (perte de focus), le texte est remplacé par le résultat sélectionné s’il y en a un, ou vidé sinon.
 *
 * @param textField le champ textuel associé
 * @param stopO la valeur observable contenant le nom de l'arrêt sélectionné ou une chaîne vide si aucun n'est sélectionné
 *
 * @author Omar Ziyad Azgaoui (379136)
 * @author Mohamed Amine Goulahsen (400232)
 */
public record StopField(TextField textField, ObservableValue<String> stopO) {

    private static final double HAUTEUR_LISTE_ARRETS = 240;
    private static final int MAX_RESULTATS_ARRETS = 30;

    /**
     * Crée un champ de recherche d'arrêt graphique permettant la sélection d'un arrêt parmi ceux présents dans l'index.
     * Affiche dynamiquement les meilleurs résultats sous forme de liste au fur et à mesure de la saisie.
     * La valeur observable associée contient le nom de l'arrêt sélectionné, ou une chaîne vide si aucun n'est sélectionné.
     *
     * @param index l’index des arrêts à utiliser pour effectuer la recherche
     * @return une instance de {@code StopField} initialisée
     */
    public static StopField create(StopIndex index) {
        TextField textField = new TextField();
        StringProperty selectedStop = new SimpleStringProperty(""); // Propriété observable du champ

        // Composant graphique affichant les suggestions d'arrêts
        ListView<String> listView = new ListView<>();
        listView.setFocusTraversable(false); // Ne doit pas intercepter le focus clavier
        listView.setMaxHeight(HAUTEUR_LISTE_ARRETS);

        // Popup contenant dynamiquement la liste des suggestions
        Popup popup = new Popup();
        popup.setAutoHide(true); // Se ferme automatiquement en cas de clic hors-champ
        popup.setHideOnEscape(false); // Ne se ferme pas avec Échap
        popup.getContent().add(listView); // Ajoute la liste dans le popup

        // Listener réagissant aux modifications du champ pour mettre à jour les suggestions
        ChangeListener<String> textListener = (obs, oldVal, newVal) -> {
            updateList(index, newVal, listView); // Recalcule les résultats
            if (!popup.isShowing() && textField.isFocused()) {
                showPopup(popup, textField);     // Réouvre la popup si nécessaire
            }
        };

        // Repositionne dynamiquement le popup sous le champ en cas de redimensionnement ou décalage
        ChangeListener<Bounds> boundsListener = (obs, oldVal, newVal) ->
                repositionPopup(popup, textField);

        // Gère le gain et la perte de focus du champ
        textField.focusedProperty().addListener((obs, oldFocused, newFocused) -> {
            if (newFocused) {
                // Quand le champ gagne le focus, on met à jour les suggestions visibles
                updateList(index, textField.getText(), listView);
                showPopup(popup, textField);
                textField.textProperty().addListener(textListener);
                textField.boundsInLocalProperty().addListener(boundsListener);
            } else {
                // Quand on quitte le champ (Tab, clic ailleurs, etc.)
                popup.hide();
                textField.textProperty().removeListener(textListener);
                textField.boundsInLocalProperty().removeListener(boundsListener);

                // Si un élément est sélectionné dans la liste, on le valide
                String currentText = listView.getSelectionModel().getSelectedItem();

                if (currentText != null) {
                    // 1. Un élément sélectionné → on le valide
                    textField.setText(currentText);
                    selectedStop.set(currentText);
                } else {
                    // 2. Aucun élément sélectionné
                    String rawInput = textField.getText().strip();
                    if (rawInput.isEmpty()) {
                        // 2a. Champ vide → on vide aussi la sélection
                        selectedStop.set("");
                    } else {
                        // 2b. Champ non vide → on le laisse tel quel
                        selectedStop.set(rawInput);
                    }
                }
            }
        });

        // Gère les touches fléchées et Entrée dans la liste des suggestions
        textField.addEventHandler(KeyEvent.KEY_PRESSED, event -> {
            switch (event.getCode()) {
                case UP -> {
                    moveSelection(listView, false); // Sélectionne le précédent
                    event.consume();
                }
                case DOWN -> {
                    moveSelection(listView, true); // Sélectionne le suivant
                    event.consume();
                }
            }
        });

        // Clic dans le champ : affiche les suggestions à nouveau
        textField.setOnMouseClicked(e -> {
            if (!popup.isShowing() && textField.isFocused()) {
                updateList(index, textField.getText(), listView);
                showPopup(popup, textField);
            }
        });

        return new StopField(textField, selectedStop);
    }

    /**
     * Modifie le texte du champ textuel associé à ce {@code StopField}.
     *
     * @param stopName le nom de l'arrêt à afficher dans le champ textuel
     */
    public void setTo(String stopName) {
        textField.setText(stopName);
        // Mettre aussi à jour directement la valeur observable
        if (stopO instanceof StringProperty sp) {
            sp.set(stopName);
        }
    }

    /**
     * Met à jour la liste des suggestions affichées dans le {@code ListView} à partir de la requête entrée.
     *
     * @param index l’index des arrêts
     * @param query la chaîne de caractères tapée par l’utilisateur
     * @param listView la liste des résultats à mettre à jour
     */
    private static void updateList(StopIndex index, String query, ListView<String> listView) {
        List<String> results = index.stopsMatching(query, MAX_RESULTATS_ARRETS);
        ObservableList<String> items = FXCollections.observableArrayList(results);
        listView.setItems(items);
        if (!items.isEmpty())
            listView.getSelectionModel().selectFirst(); // Met toujours le meilleur résultat en premier
    }

    /**
     * Affiche le popup contenant la liste des suggestions sous le champ textuel.
     *
     * @param popup le popup à afficher
     * @param tf le champ textuel de référence
     */
    private static void showPopup(Popup popup, TextField tf) {
        Bounds screenBounds = tf.localToScreen(tf.getBoundsInLocal());
        popup.show(tf, screenBounds.getMinX(), screenBounds.getMaxY());
    }

    /**
     * Repositionne dynamiquement le popup selon la position du champ textuel.
     *
     * @param popup le popup à repositionner
     * @param tf le champ textuel de référence
     */
    private static void repositionPopup(Popup popup, TextField tf) {
        if (!popup.isShowing()) return;
        Bounds screenBounds = tf.localToScreen(tf.getBoundsInLocal());
        popup.setAnchorX(screenBounds.getMinX());
        popup.setAnchorY(screenBounds.getMaxY());
    }

    /**
     * Modifie la sélection actuelle dans la liste selon la direction spécifiée.
     *
     * @param listView la liste des suggestions
     * @param directionDown {@code true} pour aller vers le bas, {@code false} pour aller vers le haut
     */
    private static void moveSelection(ListView<String> listView, boolean directionDown) {
        int i = listView.getSelectionModel().getSelectedIndex();
        int itemCount = listView.getItems().size();
        int newIndex = directionDown ? i + 1 : i - 1;

        if ((directionDown && i < itemCount - 1) || (!directionDown && i > 0)) {
            listView.getSelectionModel().select(newIndex);
            listView.scrollTo(newIndex);
        }
    }
}