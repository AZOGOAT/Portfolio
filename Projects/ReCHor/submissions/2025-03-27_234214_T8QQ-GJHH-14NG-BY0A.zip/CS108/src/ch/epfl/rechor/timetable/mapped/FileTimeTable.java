package ch.epfl.rechor.timetable.mapped;

import ch.epfl.rechor.timetable.*;
import java.io.IOException;
import java.io.UncheckedIOException;
import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;
import static java.nio.channels.FileChannel.MapMode.READ_ONLY;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;

public record FileTimeTable(Path directory,
                            List<String> stringTable,
                            Stations stations,
                            StationAliases stationAliases,
                            Platforms platforms,
                            Routes routes,
                            Transfers transfers)
        implements TimeTable {

    public static TimeTable in(Path directory) throws IOException {
        // Lire la table des chaînes de caractères avec l'encodage ISO-8859-1
        List<String> stringTable = Files.readAllLines(directory.resolve("strings.txt"), StandardCharsets.ISO_8859_1);

        // Ouvrir les canaux pour les fichiers binaires
        FileChannel stationsChannel = FileChannel.open(directory.resolve("stations.bin"));
        FileChannel stationAliChannel = FileChannel.open(directory.resolve("station-aliases.bin"));
        FileChannel platformChannel = FileChannel.open(directory.resolve("platforms.bin"));
        FileChannel routeChannel = FileChannel.open(directory.resolve("routes.bin"));
        FileChannel transferChannel = FileChannel.open(directory.resolve("transfers.bin"));

        try (stationsChannel; stationAliChannel; platformChannel; routeChannel; transferChannel) {
            // Mapper les fichiers binaires en mémoire
            ByteBuffer stationsBuffer = stationsChannel.map(READ_ONLY, 0, stationsChannel.size());
            ByteBuffer stationAliasesBuffer = stationAliChannel.map(READ_ONLY, 0, stationAliChannel.size());
            ByteBuffer platformsBuffer = platformChannel.map(READ_ONLY, 0, platformChannel.size());
            ByteBuffer routesBuffer = routeChannel.map(READ_ONLY, 0, routeChannel.size());
            ByteBuffer transferBuffer = transferChannel.map(READ_ONLY, 0, transferChannel.size());

            return new FileTimeTable(directory,
                    stringTable,
                    new BufferedStations(stringTable, stationsBuffer),
                    new BufferedStationAliases(stringTable, stationAliasesBuffer),
                    new BufferedPlatforms(stringTable, platformsBuffer),
                    new BufferedRoutes(stringTable, routesBuffer),
                    new BufferedTransfers(transferBuffer));
        }
    }

    @Override
    public Trips tripsFor(LocalDate date) {
        try {
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
            Path dayDirectory = directory.resolve(date.format(formatter));
            Path tripsPath = dayDirectory.resolve("trips.bin");
            FileChannel tripsChannel = FileChannel.open(tripsPath);

            try (tripsChannel) {
                ByteBuffer tripsBuffer = tripsChannel.map(READ_ONLY, 0, tripsChannel.size());
                return new BufferedTrips(stringTable, tripsBuffer);
            }
        } catch (IOException e) {
            throw new UncheckedIOException(e);
        }
    }

    @Override
    public Connections connectionsFor(LocalDate date) {
        try {
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
            Path dayDirectory = directory.resolve(date.format(formatter));
            Path connectionsPath = dayDirectory.resolve("connections.bin");
            Path succPath = dayDirectory.resolve("connections-succ.bin");

            FileChannel connectionsChannel = FileChannel.open(connectionsPath);
            FileChannel succChannel = FileChannel.open(succPath);

            try (connectionsChannel; succChannel) {
                ByteBuffer connectionsBuffer = connectionsChannel.map(READ_ONLY, 0, connectionsChannel.size());
                ByteBuffer succBuffer = succChannel.map(READ_ONLY, 0, succChannel.size());
                return new BufferedConnections(connectionsBuffer, succBuffer);
            }
        } catch (IOException e) {
            throw new UncheckedIOException(e);
        }
    }
}
