package ch.epfl.rechor.journey;

import static ch.epfl.rechor.journey.PackedCriteria.*;
import ch.epfl.rechor.timetable.Connections;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

/**
 * Classe qui permet d'extraire les voyages optimaux à partir d'un profil.
 * Un voyage est extrait en utilisant la charge utile (payload) qui contient :
 * - L'ID de la première connexion à prendre (24 bits de poids fort)
 * - Le nombre d'arrêts à sauter avant de descendre (8 bits de poids faible)
 */
public class JourneyExtractor {
    // La charge utile contient deux informations empaquetées dans un int :
    private static final int CONNECTION_ID_SHIFT = 8;  // L'ID de connexion occupe les 24 bits de poids fort
    private static final int STOPS_TO_SKIP_MASK = 0xFF;  // Le nombre d'arrêts à sauter occupe les 8 bits de poids faible

    // Extrait l'ID de la connexion des 24 bits de poids fort
    private static int extractConnectionId(int payload) {
        return payload >>> CONNECTION_ID_SHIFT;
    }

    // Extrait le nombre d'arrêts à sauter des 8 bits de poids faible
    private static int extractStopsToSkip(int payload) {
        return payload & STOPS_TO_SKIP_MASK;
    }

    /**
     * Retourne tous les voyages optimaux pour un profil et une gare de départ donnés.
     * Les voyages sont triés par heure de départ puis par heure d'arrivée.
     */
    public static List<Journey> journeys(Profile profile, int depStationId) {
        List<Journey> journeys = new ArrayList<>();

        // Obtenir la frontière de Pareto pour la gare de départ
        ParetoFront pf = profile.forStation(depStationId);

        // Pour chaque critère dans la frontière de Pareto
        pf.forEach((long criteria) -> {
            List<Journey.Leg> legs = new ArrayList<>();
            // Extraire le voyage correspondant à ce critère
            extractJourney(profile, criteria, legs);
            if (!legs.isEmpty()) {
                journeys.add(new Journey(legs));
            }
        });

        // Trier les voyages comme demandé dans l'énoncé
        journeys.sort(Comparator
                .comparing(Journey::depTime)
                .thenComparing(Journey::arrTime));

        return journeys;
    }

    /**
     * Extrait récursivement un voyage à partir d'un critère.
     * Pour chaque critère :
     * 1. On trouve la première connexion à prendre (dans la charge utile)
     * 2. On suit les connexions jusqu'à avoir sauté le bon nombre d'arrêts
     * 3. On crée une étape de transport avec les arrêts intermédiaires
     * 4. On continue avec la frontière de Pareto de la gare d'arrivée
     */
    private static void extractJourney(Profile profile, long criteria, List<Journey.Leg> legs) {
        // 1. Extraire les infos du critère
        int targetArrMins = arrMins(criteria);
        int remainingChanges = changes(criteria);
        int connectionId = extractConnectionId(payload(criteria));
        int stopsToSkip = extractStopsToSkip(payload(criteria));

        // 2. Obtenir les infos de la connexion à prendre
        Connections connections = profile.connections();

        // Collecter les arrêts intermédiaires
        List<Journey.Leg.IntermediateStop> intermediateStops = new ArrayList<>();
        int currentConnId = connectionId;

        // Suivre les connexions jusqu'à l'arrêt où on doit descendre
        for (int i = 0; i < stopsToSkip - 1; i++) {  // -1 car on ne veut pas inclure l'arrêt d'arrivée
            int nextConnId = connections.nextConnectionId(currentConnId);

            // Ajouter l'arrêt d'arrivée de la connexion courante comme arrêt intermédiaire
            int intermediateStopId = connections.arrStopId(currentConnId);
            int intermediateArrMins = connections.arrMins(currentConnId);
            int intermediateDepMins = connections.depMins(nextConnId);

            intermediateStops.add(new Journey.Leg.IntermediateStop(
                    createStop(profile, intermediateStopId),
                    profile.date().atTime(intermediateArrMins / 60, intermediateArrMins % 60),
                    profile.date().atTime(intermediateDepMins / 60, intermediateDepMins % 60)
            ));

            // Passer à la connexion suivante
            currentConnId = nextConnId;
        }

        // Obtenir les informations finales
        int finalConnId = currentConnId;
        if (stopsToSkip > 0) {
            finalConnId = connections.nextConnectionId(currentConnId);
        }

        int arrStopId = connections.arrStopId(finalConnId);
        int arrMins = connections.arrMins(finalConnId);
        int tripId = connections.tripId(finalConnId);

        // 3. Créer les stops
        Stop depStop = createStop(profile, connections.depStopId(connectionId));
        Stop arrStop = createStop(profile, arrStopId);

        // 4. Si on n'est pas au début du voyage ou si on doit commencer par une étape à pied
        if (!legs.isEmpty()) {
            Journey.Leg lastLeg = legs.get(legs.size() - 1);

            // Si la dernière étape était un transport, on doit ajouter une étape à pied
            if (lastLeg instanceof Journey.Leg.Transport) {
                legs.add(new Journey.Leg.Foot(
                        lastLeg.arrStop(),
                        lastLeg.arrTime(),
                        depStop,
                        profile.date().atTime(connections.depMins(connectionId) / 60, connections.depMins(connectionId) % 60)
                ));
            }
            // Si la dernière étape était à pied, on ne fait rien car on va ajouter un transport
        }
        // Si on est au début du voyage et que le départ n'est pas une gare
        else if (!profile.timeTable().isStationId(connections.depStopId(connectionId))) {
            // On doit commencer par une étape à pied depuis la gare jusqu'au quai
            Stop stationStop = createStop(profile, profile.timeTable().stationId(connections.depStopId(connectionId)));
            legs.add(new Journey.Leg.Foot(
                    stationStop,
                    profile.date().atTime(connections.depMins(connectionId) / 60, connections.depMins(connectionId) % 60),
                    depStop,
                    profile.date().atTime(connections.depMins(connectionId) / 60, connections.depMins(connectionId) % 60)
            ));
        }

        // 5. Ajouter l'étape de transport avec les arrêts intermédiaires
        legs.add(new Journey.Leg.Transport(
                depStop,
                profile.date().atTime(connections.depMins(connectionId) / 60, connections.depMins(connectionId) % 60),
                arrStop,
                profile.date().atTime(arrMins / 60, arrMins % 60),
                intermediateStops,
                profile.timeTable().routes().vehicle(profile.trips().routeId(tripId)),
                profile.timeTable().routes().name(profile.trips().routeId(tripId)),
                profile.trips().destination(tripId)
        ));

        // 6. Si on n'a pas fini, chercher le prochain critère
        if (remainingChanges > 0) {
            int arrStationId = profile.timeTable().stationId(arrStopId);
            ParetoFront nextPf = profile.forStation(arrStationId);

            nextPf.forEach((long nextCriteria) -> {
                if (arrMins(nextCriteria) == targetArrMins &&
                        changes(nextCriteria) == remainingChanges - 1) {
                    extractJourney(profile, nextCriteria, legs);
                }
            });
        }
    }

    /**
     * Crée un Stop à partir d'un ID d'arrêt.
     * Gère automatiquement la conversion entre ID d'arrêt et ID de station.
     */
    private static Stop createStop(Profile profile, int stopId) {
        int stationId = profile.timeTable().stationId(stopId);
        return new Stop(
                profile.timeTable().stations().name(stationId),
                profile.timeTable().platformName(stopId),
                profile.timeTable().stations().longitude(stationId),
                profile.timeTable().stations().latitude(stationId)
        );
    }
}
