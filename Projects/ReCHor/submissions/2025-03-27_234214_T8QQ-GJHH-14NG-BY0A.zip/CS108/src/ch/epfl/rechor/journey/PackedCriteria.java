package ch.epfl.rechor.journey;

import ch.epfl.rechor.Preconditions;

/**
 * Classe utilitaire non instanciable permettant de manipuler des critères
 * d'optimisation augmentés, empaquetés dans des valeurs de type {@code long}.
 *
 * <p>Les critères augmentés contiennent :</p>
 * <ul>
 *   <li>Les 32 bits de poids fort représentant les critères d'optimisation :</li>
 *   <ul>
 *     <li>Le bit 63 : toujours égal à 0 pour garantir le signe positif (1 bit).</li>
 *     <li>Les bits 62 à 51 : heure de départ en minutes (12 bits).</li>
 *     <li>Les bits 50 à 39 : heure d'arrivée en minutes (12 bits).</li>
 *     <li>Les bits 38 à 32 : nombre de changements (7 bits).</li>
 *   </ul>
 *   <li>Les 32 bits de poids faible représentant la charge utile (payload), permettant de stocker des informations supplémentaires nécessaires pour la reconstruction des voyages.</li>
 * </ul>
 *
 * <p>Dans certains cas, les critères ne contiennent pas d'heure de départ.
 * Cette absence est représentée en fixant à 0 les bits correspondant à l'heure de départ.</p>
 *
 * <p>Les heures de départ et d'arrivée sont exprimées en minutes écoulées depuis minuit,
 * et sont valides si elles sont comprises entre -240 (inclus) et 2880 (exclu).
 * Ces valeurs sont translatées pour garantir des représentations positives, simplifiant ainsi les manipulations bit à bit.</p>
 *
 * @author Omar Ziyad Azgaoui (379136)
 * @author Mohamed Amine Goulahsen (400232)
 */

public class PackedCriteria {
    /**
     * Constructeur privé pour empêcher l'instanciation de la classe.
     */
    private PackedCriteria() {}

    /**
     * Empaquette les critères sous forme d'une valeur de type {@code long}.
     *
     * @param arrMins l'heure d'arrivée en minutes écoulées depuis minuit.
     * @param changes le nombre de changements (doit tenir sur 7 bits).
     * @param payload la charge utile associée.
     * @return les critères empaquetés sous forme d'un entier long.
     * @throws IllegalArgumentException si :
     * <ul>
     *   <li>Les minutes d'arrivée ({@code arrMins}) sont en dehors de l'intervalle [-240, 2880].</li>
     *   <li>Le nombre de changements ({@code payload}) ne tient pas en 7 bits (~plus de 128 changements).</li>
     * </ul>
     */
    public static long pack(int arrMins, int changes, int payload){
        // Vérification des limites
        Preconditions.checkArgument(arrMins >= -240 && arrMins < 2880);
        Preconditions.checkArgument(changes >> 7 == 0);

        // Masquage correct et encodage
        long arrMinsMasked = ((long)((arrMins + 240) & 0xFFF)) << 39;
        long changesMasked = ((long) (changes & 0x7F)) << 32;
        long payloadMasked = Integer.toUnsignedLong(payload);

        return arrMinsMasked | changesMasked | payloadMasked;
    }

    /**
     * Indique si les critères empaquetés incluent une heure de départ.
     *
     * @param criteria les critères empaquetés.
     * @return {@code true} si une heure de départ est incluse, {@code false} sinon.
     */
    public static boolean hasDepMins(long criteria) {
        return (((criteria >> 51) & 0xFFF) != 0);
    }

    /**
     * Retourne l'heure de départ en minutes (après minuit).
     *
     * @param criteria les critères empaquetés.
     * @return l'heure de départ en minutes.
     * @throws IllegalArgumentException si {@code criteria} n'inclue aucune heure de départ.
     */
    public static int depMins(long criteria) {
        Preconditions.checkArgument(hasDepMins(criteria));
        int storedDep = (int)((criteria >> 51) & 0xFFF);
        return 4095 - storedDep - 240;
    }
    /**
     * Retourne l'heure d'arrivée en minutes (après minuit).
     *
     * @param criteria les critères empaquetés.
     * @return l'heure d'arrivée en minutes.
     */
    public static int arrMins(long criteria) {
        return ((int) ((criteria >> 39) & 0xFFF)) - 240;
    }

    /**
     * Retourne le nombre de changements des critères empaquetés.
     *
     * @param criteria les critères empaquetés.
     * @return le nombre de changements.
     */
    public static int changes(long criteria) {
        return (int) ((criteria >> 32) & 0x7F);
    }

    /**
     * Retourne la "charge utile" associée aux critères empaquetés.
     *
     * @param criteria les critères empaquetés.
     * @return la charge utile sous forme d'un entier.
     */
    public static int payload(long criteria){
        return (int) (criteria & 0xFFFFFFFFL);
    }
    /**
     * Vérifie si les premiers critères dominent ou sont égaux aux seconds.
     *
     * @param criteria1 les premiers critères empaquetés.
     * @param criteria2 les seconds critères empaquetés.
     * @return {@code true} si les premiers dominent ou sont égaux, {@code false} sinon.
     * @throws IllegalArgumentException si un ensemble ({@code criteria1}) possède une heure de départ et l'autre ({@code criteria2}) non.
     */
    public static boolean dominatesOrIsEqual(long criteria1, long criteria2) {
        Preconditions.checkArgument(hasDepMins(criteria1) == hasDepMins(criteria2));
        boolean criterias = arrMins(criteria1) <= arrMins(criteria2) &&
                changes(criteria1) <= changes(criteria2);
        if (hasDepMins(criteria1)) {
            boolean dep = depMins(criteria1) >= depMins(criteria2);
            return criterias && dep;
        }
        return criterias;
    }

    /**
     * @param criteria les critères empaquetés.
     * @return les critères sans l'heure de départ.
     */
    public static long withoutDepMins(long criteria){
        return criteria & ~(((1L << 12)-1) <<51);
    }

    /**
     * @param criteria les critères empaquetés.
     * @param depMins l'heure de départ à ajouter (en minutes).
     * @return les critères avec l'heure de départ ajoutée.
     */
    public static long withDepMins(long criteria, int depMins){
        criteria &= ~(((1L << 12) - 1) << 51);
        // Stocke le complément de l'heure de départ
        int storedDep = 4095 - (depMins + 240);
        return criteria | (((long) storedDep & 0xFFF) << 51);
    }

    /**
     * Incrémente le nombre de changements des critères empaquetés de 1.
     *
     * @param criteria les critères empaquetés.
     * @return les critères avec un changement supplémentaire.
     */
    public static long withAdditionalChange(long criteria){
        int currentChanges = changes(criteria);
        int newChanges = currentChanges + 1;
        return (criteria & ~(0x7FL << 32)) | ((((long) newChanges) & 0x7F) << 32);
    }

    /**
     * @param criteria les critères empaquetés.
     * @param payload1 la nouvelle charge utile.
     * @return les critères avec la charge utile.
     */
    public static long withPayload(long criteria, int payload1){
        long payloadMasked = Integer.toUnsignedLong(payload1);
        return (criteria & ~0xFFFFFFFFL) | (payloadMasked);
    }
}