package ch.epfl.rechor;

import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import static java.util.regex.Pattern.CASE_INSENSITIVE;
import static java.util.regex.Pattern.UNICODE_CASE;

/**
 * Classe permettant de rechercher efficacement des arrêts à partir d'une requête de l'utilisateur.
 * <p>
 * Un arrêt peut être recherché à l’aide d’une requête composée de plusieurs sous-requêtes séparées par des espaces.
 * Un nom d’arrêt correspond à une requête s’il contient chacune des sous-requêtes, l’ordre n’étant pas important.
 * Le test est accent-insensible, et insensible à la casse si aucune majuscule n’est présente dans la sous-requête.
 * Les noms d’arrêts peuvent aussi être des alias d’autres noms principaux.
 * Les résultats sont triés par pertinence décroissante, puis par ordre lexicographique.
 * </p>
 *
 * @author Omar Ziyad Azgaoui (379136)
 * @author Mohamed Amine Goulahsen (400232)
 */
public final class StopIndex {

    private static final int FACTEUR_DEBUT_MOT = 4;
    private static final int FACTEUR_FIN_MOT = 2;
    private static final double SCORE_POURCENTAGE = 100.0;
    // Table des équivalences de lettres pour une correspondance accent-insensible
    private static final Map<Character, String> EQUIVALENT_CHARS = Map.of('c',
                                                                          "cç",
                                                                          'a',
                                                                          "aáàâä",
                                                                          'e',
                                                                          "eéèêë",
                                                                          'i',
                                                                          "iíìîï",
                                                                          'o',
                                                                          "oóòôö",
                                                                          'u',
                                                                          "uúùûü");
    // Noms principaux des arrêts (p. ex. Lausanne, Renens VD, etc.)
    private final Set<String> mainStopNames;
    // Table des alias associant un nom alternatif à son nom principal (p. ex. Losanna → Lausanne)
    private final Map<String, String> aliasToMain;

    /**
     * Construit un index des arrêts à partir de leurs noms principaux et d’un dictionnaire d’alias.
     *
     * @param stopNames la liste des noms principaux des arrêts.
     * @param aliases la table des alias, associant chaque nom alternatif à un nom principal.
     */
    public StopIndex(List<String> stopNames, Map<String, String> aliases) {
        this.mainStopNames = new HashSet<>(stopNames);
        this.aliasToMain = Map.copyOf(aliases);
    }

    /**
     * Retourne les noms des arrêts correspondant à une requête, triés par pertinence décroissante,
     * puis par ordre lexicographique, et limités au nombre maximal donné.
     * <p>
     * Une requête vide ou constituée uniquement d’espaces retourne une liste vide.
     * </p>
     *
     * @param query la requête de l’utilisateur.
     * @param maxResults le nombre maximal de résultats à retourner.
     * @return la liste des noms des arrêts correspondant à la requête.
     */
    public List<String> stopsMatching(String query, int maxResults) {

        // Cas limite : requête vide ou faite uniquement d'espaces → aucun résultat
        if (query.isBlank()) return List.of();

        List<Pattern> subQueries = subQueryPatterns(query);
        Set<String> matched = new HashSet<>(); // Pour éviter les doublons
        List<Match> matches = new ArrayList<>();

        // Recherche dans tous les noms (principaux et alias)
        for (String name : unionOfStopNames()) {
            // Canonicalise le nom (alias → principal)
            String canonical = mainStopNames.contains(name) ? name : aliasToMain.get(name);

            // Optimisat° : ignorer les alias non mappés ou mappés vers un nom non présent.
            if (!mainStopNames.contains(canonical)) continue;

            // Optimisat° : ne traiter chaque nom principal qu'une seule fois (ex: alias multiples)
            if (matched.contains(canonical)) continue;

            // Calcul du score de pertinence
            OptionalInt score = relevanceScore(name, subQueries);
            // Cas limite : un nom ne contenant pas toutes les sous-requêtes est éliminé
            if (score.isPresent()) {
                matches.add(new Match(canonical, score.getAsInt()));
                matched.add(canonical); // Retenu une seule fois
            }
        }

        // Tri décroissant par score, puis lexicographique
        matches.sort(Comparator.<Match>comparingInt(m -> -m.score)
                               .thenComparing(m -> m.name));

        // Extraction des noms (limités à maxResults)
        return matches.stream()
                      .limit(maxResults)
                      .map(m -> m.name)
                      .toList();
    }

    /**
     * Transforme la requête de l’utilisateur en une liste de patterns regex,
     * un par sous-requête séparée par des espaces.
     * <p>
     * Chaque pattern est accent-insensible, et insensible à la casse si aucune majuscule n’est présente.
     * </p>
     *
     * @param query la requête utilisateur à traiter.
     * @return la liste des patterns correspondant aux sous-requêtes.
     */
    private static List<Pattern> subQueryPatterns(String query) {
        return Arrays.stream(query.strip().split("\\s+"))// découpe par sous-requête
                     .map(StopIndex::toRegexPattern)
                     .toList();
    }

    /**
     * Transforme une sous-requête en pattern regex :
     * <ul>
     *     <li>Sensible à la casse si la sous-requête contient une majuscule.</li>
     *     <li>Insensible à la casse sinon (avec CASE_INSENSITIVE | UNICODE_CASE).</li>
     *     <li>Accent-insensible dans tous les cas.</li>
     * </ul>
     *
     * @param subQuery la sous-requête à transformer.
     * @return le pattern regex correspondant.
     */
    private static Pattern toRegexPattern(String subQuery) {
        String regex = toRegex(subQuery);
        boolean hasUpper = subQuery.chars().anyMatch(Character::isUpperCase);
        // Edge case : casse respectée uniquement si majuscule présente
        int flags = hasUpper ? 0 : (CASE_INSENSITIVE | UNICODE_CASE);
        return Pattern.compile(regex, flags);
    }

    /**
     * Génère une expression régulière qui tolère les accents selon les correspondances définies
     * dans {@code EQUIVALENT_CHARS}.
     * <p>
     * Chaque lettre de la sous-requête est remplacée par une classe de caractères
     * contenant toutes ses variantes accentuées.
     * </p>
     *
     * @param subQuery la sous-requête à convertir en expression régulière.
     * @return une chaîne représentant l'expression régulière équivalente.
     */
    private static String toRegex(String subQuery) {
        StringBuilder regex = new StringBuilder();
        for (char c : subQuery.toCharArray()) {
            if (Character.isLetter(c)) {
                String equivalents = EQUIVALENT_CHARS.getOrDefault(Character.toLowerCase(c),
                                                                   String.valueOf(c));
                regex.append("[")
                     .append(Pattern.quote(equivalents))
                     .append("]");
            } else {
                // Edge case : ponctuation ou chiffre, pas transformé
                regex.append(Pattern.quote(String.valueOf(c)));
            }
        }
        return regex.toString();
    }

    /**
     * Calcule le score de pertinence d’un nom d’arrêt par rapport à une liste de patterns regex.
     * <p>
     * Le score est basé sur la proportion du nom correspondant à chaque sous-requête,
     * multiplié par un facteur si le match est en début ou fin de mot.
     * </p>
     * <p>
     * Si le nom ne correspond pas à toutes les sous-requêtes, il est éliminé.
     * </p>
     *
     * @param stopName le nom d’arrêt à évaluer.
     * @param patterns la liste des sous-requêtes sous forme de patterns.
     * @return le score total de pertinence, ou vide si le nom ne correspond pas.
     */
    private static OptionalInt relevanceScore(String stopName, List<Pattern> patterns) {
        int totalScore = 0;
        for (Pattern pattern : patterns) {
            Matcher matcher = pattern.matcher(stopName);
            // Edge case : on ignore le nom s’il ne contient pas une sous-requête
            if (!matcher.find())
                return OptionalInt.empty();

            // Score de base = % de la longueur du nom correspondant à la sous-requête
            int matchLength = matcher.end() - matcher.start(); // début de mot
            int baseScore = (int) Math.floor(SCORE_POURCENTAGE * matchLength / stopName.length()); // fin de mot

            int multiplier = 1;
            if (isWordStart(stopName, matcher.start()))
                multiplier *= FACTEUR_DEBUT_MOT;
            if (isWordEnd(stopName, matcher.end()))
                multiplier *= FACTEUR_FIN_MOT;

            totalScore += baseScore * multiplier;
        }
        return OptionalInt.of(totalScore);
    }

    /**
     * Indique si la position donnée est le début d’un mot, ou le début de la chaîne.
     *
     * @param text le texte dans lequel vérifier.
     * @param pos la position dans le texte.
     * @return {@code true} si la position est un début de mot, {@code false} sinon.
     */
    private static boolean isWordStart(String text, int pos) {
        return pos == 0 || !Character.isLetter(text.charAt(pos - 1));
    }

    /**
     * Indique si la position donnée est la fin d’un mot, ou la fin de la chaîne.
     *
     * @param text le texte dans lequel vérifier.
     * @param pos la position dans le texte.
     * @return {@code true} si la position est une fin de mot, {@code false} sinon.
     */
    private static boolean isWordEnd(String text, int pos) {
        return pos == text.length() ||
               (pos < text.length() && !Character.isLetter(text.charAt(pos)));
    }

    /**
     * Retourne l’union des noms principaux et des alias, pour la recherche.
     *
     * @return l’ensemble des noms d’arrêts à prendre en compte pour la recherche.
     */
    private Set<String> unionOfStopNames() {
        Set<String> all = new HashSet<>(mainStopNames);
        all.addAll(aliasToMain.keySet());
        return all;
    }

    /**
     * Enregistrement représentant un nom d'arrêt associé à un score de pertinence.
     * <p>
     * Utilisé comme structure de données interne pour mémoriser les arrêts correspondant à une requête,
     * en vue de les trier par pertinence.
     * </p>
     *
     * <p>
     * Chaque correspondance est représentée par le nom canonique (i.e. principal) de l’arrêt
     * et par un score calculé selon des critères définis dans {@link #relevanceScore(String, List)}.
     * Ce score reflète la qualité du match entre le nom et la requête utilisateur.
     * </p>
     *
     * <p>
     * Cette structure permet de centraliser la logique de tri des résultats : une fois tous les arrêts
     * correspondants stockés dans des objets {@code Match}, la méthode {@link #stopsMatching(String, int)}
     * peut facilement les trier à l’aide d’un comparateur combiné (par score décroissant, puis par ordre lexicographique),
     * puis les convertir en simple liste de noms.
     * </p>
     *
     * @param name le nom principal (canonique) de l'arrêt correspondant.
     * @param score le score de pertinence calculé selon les sous-requêtes de la requête utilisateur.
     */
    private record Match(String name, int score) {
    }
}