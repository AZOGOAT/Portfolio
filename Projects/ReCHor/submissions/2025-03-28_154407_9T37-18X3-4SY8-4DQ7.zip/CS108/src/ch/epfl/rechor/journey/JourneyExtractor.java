package ch.epfl.rechor.journey;

import static ch.epfl.rechor.journey.PackedCriteria.*;
import ch.epfl.rechor.timetable.Connections;
import ch.epfl.rechor.timetable.TimeTable;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

/**
 * Classe qui permet d'extraire les voyages optimaux à partir d'un profil.
 * Un voyage est extrait en utilisant la charge utile (payload) qui contient :
 * - L'ID de la première connexion à prendre (24 bits de poids fort)
 * - Le nombre d'arrêts à sauter avant de descendre (8 bits de poids faible)
 */
public class JourneyExtractor {
    // La charge utile contient deux informations empaquetées dans un int :
    private static final int CONNECTION_ID_SHIFT = 8;  // L'ID de connexion occupe les 24 bits de poids fort
    private static final int STOPS_TO_SKIP_MASK = 0xFF;  // Le nombre d'arrêts à sauter occupe les 8 bits de poids faible
    private static final int DEFAULT_TRANSFER_MINUTES = 5; // Valeur par défaut pour les transferts

    // Extrait l'ID de la connexion des 24 bits de poids fort
    private static int extractConnectionId(int payload) {
        return payload >>> CONNECTION_ID_SHIFT;
    }

    // Extrait le nombre d'arrêts à sauter des 8 bits de poids faible
    private static int extractStopsToSkip(int payload) {
        return payload & STOPS_TO_SKIP_MASK;
    }

    /**
     * Retourne tous les voyages optimaux pour un profil et une gare de départ donnés.
     * Les voyages sont triés par heure de départ puis par heure d'arrivée.
     */
    public static List<Journey> journeys(Profile profile, int depStationId) {
        List<Journey> journeys = new ArrayList<>();

        // Obtenir la frontière de Pareto pour la gare de départ
        ParetoFront pf = profile.forStation(depStationId);

        // Pour chaque critère dans la frontière de Pareto
        pf.forEach((long criteria) -> {
            List<Journey.Leg> legs = new ArrayList<>();
            // Extraire le voyage correspondant à ce critère en passant la station de départ
            extractJourney(profile, criteria, legs, depStationId);
            if (!legs.isEmpty()) {
                journeys.add(new Journey(legs));
            }
        });

        // Trier les voyages comme demandé dans l'énoncé
        journeys.sort(Comparator
                .comparing(Journey::depTime)
                .thenComparing(Journey::arrTime));

        return journeys;
    }

    /**
     * Extrait récursivement un voyage à partir d'un critère.
     * Pour chaque critère :
     * 1. On trouve la première connexion à prendre (dans la charge utile)
     * 2. On suit les connexions jusqu'à avoir sauté le bon nombre d'arrêts
     * 3. On crée une étape de transport avec les arrêts intermédiaires
     * 4. On continue avec la frontière de Pareto de la gare d'arrivée
     */
    private static void extractJourney(Profile profile, long criteria, List<Journey.Leg> legs, int initialDepStationId) {
        // 1. Extraire les infos du critère
        int targetArrMins = arrMins(criteria);
        int remainingChanges = changes(criteria);
        int connectionId = extractConnectionId(payload(criteria));
        int stopsToSkip = extractStopsToSkip(payload(criteria));

        // 2. Obtenir les infos de la connexion à prendre
        Connections connections = profile.connections();
        TimeTable timeTable = profile.timeTable();

        // Collecter les arrêts intermédiaires
        List<Journey.Leg.IntermediateStop> intermediateStops = new ArrayList<>();
        int currentConnId = connectionId;

        // Suivre les connexions jusqu'à l'arrêt où on doit descendre
        for (int i = 0; i < stopsToSkip; i++) {
            int nextConnId = connections.nextConnectionId(currentConnId);

            // Ajouter l'arrêt d'arrivée de la connexion courante comme arrêt intermédiaire
            int intermediateStopId = connections.arrStopId(currentConnId);
            int intermediateArrMins = connections.arrMins(currentConnId);
            int intermediateDepMins = connections.depMins(nextConnId);

            intermediateStops.add(new Journey.Leg.IntermediateStop(
                    createStop(profile, intermediateStopId),
                    profile.date().atStartOfDay().plusMinutes(intermediateArrMins),
                    profile.date().atStartOfDay().plusMinutes(intermediateDepMins)
            ));

            // Passer à la connexion suivante
            currentConnId = nextConnId;
        }

        // Obtenir les informations finales
        int finalConnId = currentConnId;

        int depStopId = connections.depStopId(connectionId);
        int arrStopId = connections.arrStopId(finalConnId);
        int depMins = connections.depMins(connectionId);
        int arrMins = connections.arrMins(finalConnId);
        int tripId = connections.tripId(finalConnId);

        // 3. Créer les stops
        Stop depStop = createStop(profile, depStopId);
        Stop arrStop = createStop(profile, arrStopId);

        // Obtenir les IDs des stations correspondantes (pas des arrêts/quais)
        int depStationId = timeTable.stationId(depStopId);
        int arrStationId = timeTable.stationId(arrStopId);

        // 4. Gérer les étapes à pied selon le contexte

        // Cas 1: Étape initiale à pied si on démarre d'une station différente
        if (legs.isEmpty() && initialDepStationId != depStationId) {
            // Créer un stop pour la station de départ initiale
            Stop initialStop = createStop(profile, initialDepStationId);

            // IMPORTANT: S'assurer que les IDs utilisés sont bien des IDs de stations
            // et non des IDs d'arrêts/quais
            int transferMinutes;

            // Utiliser minutesBetween avec les IDs de stations (et non des arrêts)
            transferMinutes = timeTable.transfers().minutesBetween(initialDepStationId, depStationId);


            // Heure de départ du premier transport
            LocalDateTime depTime = profile.date().atStartOfDay().plusMinutes(depMins);

            // Heure de départ à pied = heure de départ du transport - temps de transfert
            LocalDateTime footDepTime = depTime.minusMinutes(transferMinutes);

            // Créer l'étape à pied initiale
            legs.add(new Journey.Leg.Foot(
                    initialStop,
                    footDepTime,
                    depStop,
                    depTime
            ));
        }
        // Cas 2: Étape à pied entre deux transports (transfert)
        else if (!legs.isEmpty()) {
            Journey.Leg lastLeg = legs.get(legs.size() - 1);

            // Si la dernière étape était un transport, on doit ajouter une étape à pied
            if (lastLeg instanceof Journey.Leg.Transport) {
                // Trouver la station d'arrivée de la dernière étape
                String lastStationName = lastLeg.arrStop().name();
                int lastStationId = -1;

                // Chercher la station par son nom
                for (int i = 0; i < timeTable.stations().size(); i++) {
                    if (timeTable.stations().name(i).equals(lastStationName)) {
                        lastStationId = i;
                        break;
                    }
                }

                // Si on a trouvé la station, calculer le temps de transfert
                int transferMinutes = timeTable.transfers().minutesBetween(lastStationId, depStationId);


                // Heure d'arrivée de la dernière étape
                LocalDateTime lastArrTime = lastLeg.arrTime();

                // Heure d'arrivée du transfert = heure de départ + temps de transfert
                LocalDateTime footArrTime = lastArrTime.plusMinutes(transferMinutes);

                // Heure de départ du prochain transport
                LocalDateTime nextDepTime = profile.date().atStartOfDay().plusMinutes(depMins);

                // Vérifier la cohérence temporelle
                if (footArrTime.isAfter(nextDepTime)) {
                    // Si on arrive après le départ prévu, ajuster l'heure d'arrivée
                    footArrTime = nextDepTime;
                }

                // Créer l'étape à pied
                legs.add(new Journey.Leg.Foot(
                        lastLeg.arrStop(),
                        lastArrTime,
                        depStop,
                        footArrTime
                ));
            }
        }

        // 5. Ajouter l'étape de transport
        Journey.Leg.Transport transportLeg = new Journey.Leg.Transport(
                depStop,
                profile.date().atStartOfDay().plusMinutes(depMins),
                arrStop,
                profile.date().atStartOfDay().plusMinutes(arrMins),
                intermediateStops,
                timeTable.routes().vehicle(profile.trips().routeId(tripId)),
                timeTable.routes().name(profile.trips().routeId(tripId)),
                profile.trips().destination(tripId)
        );

        legs.add(transportLeg);

        // 6. Si on n'a pas fini, chercher le prochain critère
        if (remainingChanges > 0) {
            ParetoFront nextPf = profile.forStation(arrStationId);

            nextPf.forEach((long nextCriteria) -> {
                if (arrMins(nextCriteria) == targetArrMins &&
                        changes(nextCriteria) == remainingChanges - 1) {
                    extractJourney(profile, nextCriteria, legs, initialDepStationId);
                }
            });
        }
    }

    /**
     * Crée un Stop à partir d'un ID d'arrêt.
     * Gère automatiquement la conversion entre ID d'arrêt et ID de station.
     */
    private static Stop createStop(Profile profile, int stopId) {
        TimeTable timeTable = profile.timeTable();

        // Vérifier si l'ID correspond à une station ou à un quai
        if (timeTable.isStationId(stopId)) {
            // C'est une station
            return new Stop(
                    timeTable.stations().name(stopId),
                    "", // Pas de nom de quai pour une station
                    timeTable.stations().longitude(stopId),
                    timeTable.stations().latitude(stopId)
            );
        } else {
            // C'est un quai, récupérer la station parente
            int stationId = timeTable.stationId(stopId);
            return new Stop(
                    timeTable.stations().name(stationId),
                    timeTable.platformName(stopId),
                    timeTable.stations().longitude(stationId),
                    timeTable.stations().latitude(stationId)
            );
        }
    }
}