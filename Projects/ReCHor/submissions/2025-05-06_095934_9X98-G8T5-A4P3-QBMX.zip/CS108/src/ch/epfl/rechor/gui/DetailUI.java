package ch.epfl.rechor.gui;
import ch.epfl.rechor.FormatterFr;
import ch.epfl.rechor.Json;
import ch.epfl.rechor.journey.Journey;
import javafx.beans.value.ObservableValue;
import javafx.geometry.Bounds;
import javafx.geometry.HPos;
import javafx.scene.Node;
import javafx.scene.control.Accordion;
import javafx.scene.control.Button;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TitledPane;
import javafx.scene.image.ImageView;
import javafx.scene.layout.*;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Line;
import javafx.scene.text.Text;
import javafx.stage.FileChooser;
import javafx.util.Pair;
import javafx.scene.paint.Color;

import java.awt.*;
import java.io.IOException;
import java.net.URISyntaxException;
import java.nio.file.Files;
import java.time.format.DateTimeFormatter;
import java.io.File;
import java.io.UncheckedIOException;
import java.net.URI;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import java.time.Duration;

import static ch.epfl.rechor.gui.VehicleIcons.iconFor;
import static ch.epfl.rechor.journey.JourneyGeoJsonConverter.toGeoJson;
import static ch.epfl.rechor.journey.JourneyIcalConverter.toIcalendar;
import static java.awt.Desktop.getDesktop;
import static java.time.format.DateTimeFormatter.ISO_LOCAL_DATE;

public record DetailUI(Node rootNode) {
    public static DetailUI create(ObservableValue<Journey> journey) {
        ScrollPane detailPane = new ScrollPane();
        detailPane.getStylesheets().add("detail.css");
        detailPane.setId("detail");
        StackPane firstStackPane = new StackPane();
        detailPane.setContent(firstStackPane);
        //Initialisation avec currentJourney avant d'ajouter le listener
        Journey currentJourney = journey.getValue();
        if(currentJourney == null) buildEmptyJourneyUI(firstStackPane);
        else buildDetailUI(firstStackPane, currentJourney);
        //Ajout du Listener
        journey.addListener((observable, oldj, newj) -> {
            firstStackPane.getChildren().clear();
            if(newj == null) {
                buildEmptyJourneyUI(firstStackPane);
            }
            else{
                buildDetailUI(firstStackPane, newj);
            }
        });

        return new DetailUI(detailPane);

    }

    private static void buildEmptyJourneyUI(StackPane stackPane) {
        VBox vbox = new VBox();
        vbox.setId("no-journey");
        vbox.getChildren().add(new Text("Aucun Voyage"));
        stackPane.getChildren().add(vbox);
    }

    private static void buildDetailUI(StackPane detailPane, Journey journey) {
        Json json = toGeoJson(journey);
        String jsonText = json.toString()
                .lines()
                .map(String::trim)
                .filter(s-> !s.isEmpty())
                .collect(Collectors.joining());


        VBox vbox = new VBox();
        StackPane stackPane = new StackPane();
        HBox hbox = new HBox();
        hbox.setId("buttons");
        Button Carte = new Button("Carte");
        Carte.setOnAction(e -> {
            try {
                URI uri = new URI(
                        "https",
                        "umap.osm.ch",
                        "/fr/map",
                        "data=" + jsonText,
                        null);
                Desktop.getDesktop().browse(uri);
            }
            catch(IOException ex) {
                throw new UncheckedIOException(ex);
            }catch(URISyntaxException ex) {
                throw new RuntimeException(ex);
            }

        });
        Button Calendrier = new Button("Calendrier");
        Calendrier.setOnAction(e -> {
            String Icalendar = toIcalendar(journey);
            FileChooser chooser = new FileChooser();
            chooser.setTitle("Enregistrer le voyage au format iCalendar");
            String dateStr = journey.depTime().toLocalDate().format(ISO_LOCAL_DATE);
            chooser.setInitialFileName("voyage_" + dateStr + ".ics");
            File file = chooser.showOpenDialog(detailPane.getScene().getWindow());
            if(file != null) {
                try{
                    Files.writeString(file.toPath(), Icalendar);}
                catch(IOException ex) {
                    throw new UncheckedIOException(ex);
                }
            }


        });
        hbox.getChildren().addAll(Carte, Calendrier);
        vbox.getChildren().addAll(stackPane, hbox);
        Pane annotations = new Pane();
        annotations.setId("annotations");
        AnnotatedGridPane etapes = new AnnotatedGridPane(annotations);
        etapes.setId("legs");
        int row = 0;
        for(Journey.Leg leg : journey.legs()){
            if(leg instanceof Journey.Leg.Foot foot){
                Text footText = new Text(FormatterFr.
                        formatLeg(foot));
                etapes.add(footText, 2, row, 2,1);
                row++;
            }
            else if(leg instanceof Journey.Leg.Transport tr){
                //1ere ligne
                Text deptime = new Text(FormatterFr.formatTime(tr.depTime()));
                deptime.getStyleClass().add("departure");
                GridPane.setHalignment(deptime, HPos.CENTER);
                etapes.add(deptime,0,row);
                Circle depCircle = new Circle(3);
                etapes.add(depCircle,1,row);
                Text depStop = new Text(tr.depStop().name());
                etapes.add(depStop,2,row);
                Text depPlatform = new Text(FormatterFr.formatPlatformName(tr.depStop()));
                depPlatform.getStyleClass().add("departure");
                etapes.add(depPlatform,3,row);
                row++;

                //2eme ligne
                ImageView icon = new ImageView(iconFor(tr.vehicle()));
                icon.setFitWidth(31);
                icon.setFitHeight(31);
                etapes.add(icon,0,row,1,tr.intermediateStops().isEmpty() ? 1 : 2);

                Text arrStation = new Text(FormatterFr.formatRouteDestination(tr));
                etapes.add(arrStation,2,row,2,1);
                row++;

                //3eme ligne
                if(!(tr.intermediateStops().isEmpty())){
                    Accordion accordion = new Accordion();
                    GridPane interStops = new GridPane();
                    interStops.getStyleClass().add("intermediates-stops");
                    interStops.setHgap(5);
                    interStops.setVgap(5);
                    int interStopRow = 0;
                    int size = tr.intermediateStops().size();
                    long legMinutes = Duration.between(tr.depTime(), tr.arrTime()).toMinutes();
                    Text accordionLabel = new Text(String.format("%d arrêt%s, %d min",
                            size, size > 1 ? "s" : "", legMinutes));
                    for(Journey.Leg.IntermediateStop stop : tr.intermediateStops()){
                        Text interDeptime = new Text(FormatterFr.formatTime(stop.arrTime()));
                        interStops.add(interDeptime,0,interStopRow);
                        Text interArrtime = new Text(FormatterFr.formatTime(stop.depTime()));
                        interStops.add(interArrtime,1,interStopRow);
                        Text stopName = new Text(stop.stop().name());
                        interStops.add(stopName,2,interStopRow);
                        interStopRow++;
                    }
                    TitledPane pane = new TitledPane(accordionLabel.getText(), interStops);

                    accordion.getPanes().add(pane);
                    etapes.add(accordion,2,row,2,1);
                    row++;

                }

                //4eme ligne
                Text arrTime = new Text(FormatterFr.formatTime(tr.arrTime()));
                GridPane.setHalignment(arrTime, HPos.RIGHT);
                etapes.add(arrTime,0,row);
                Circle arrCircle = new Circle(3);
                etapes.add(arrCircle,1,row);
                Text arrStop = new Text(tr.arrStop().name());
                etapes.add(arrStop,2,row);
                Text arrPlatform = new Text(FormatterFr.formatPlatformName(tr.arrStop()));
                etapes.add(arrPlatform,3,row);
                row++;
                etapes.addCirclePair(depCircle, arrCircle);
            }
        }

        stackPane.getChildren().addAll(annotations, etapes);
        detailPane.getChildren().add(vbox);

    }
    private static class AnnotatedGridPane extends GridPane {
        private Pane annotations;
        private final List<Pair<Circle,Circle>> circlePairs = new ArrayList<>();

        AnnotatedGridPane(Pane annotations) {
            this.annotations = annotations;
        }

        @Override
        public void layoutChildren(){
            super.layoutChildren();
            annotations.getChildren().clear();
            for(Pair<Circle,Circle> pair : circlePairs){
                Circle c1 = pair.getKey();
                Circle c2 = pair.getValue();
                Bounds b1 = c1.getBoundsInParent();
                Bounds b2 = c2.getBoundsInParent();
                double x1 = b1.getMinX() + b1.getWidth() / 2;
                double y1 = b1.getMinY() + b1.getHeight() / 2;
                double x2 = b2.getMinX() + b2.getWidth() / 2;
                double y2 = b2.getMinY() + b2.getHeight() / 2;
                Line line = new Line(x1, y1, x2, y2);
                line.setStroke(Color.RED);
                line.setStrokeWidth(2);
                annotations.getChildren().add(line);
            }
        }

        public void addCirclePair(Circle c1, Circle c2){
            circlePairs.add(new Pair<>(c1, c2));
        }


    }

}
