package ch.epfl.rechor;

import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import static java.util.regex.Pattern.CASE_INSENSITIVE;
import static java.util.regex.Pattern.UNICODE_CASE;

/**
 * Classe permettant de rechercher efficacement des arrêts à partir d'une requête de l'utilisateur.
 * <p>
 * Un arrêt peut être recherché à l’aide d’une requête composée de plusieurs sous-requêtes séparées par des espaces.
 * Un nom d’arrêt correspond à une requête s’il contient chacune des sous-requêtes, l’ordre n’étant pas important.
 * Le test est accent-insensible, et insensible à la casse si aucune majuscule n’est présente dans la sous-requête.
 * Les noms d’arrêts peuvent aussi être des alias d’autres noms principaux.
 * Les résultats sont triés par pertinence décroissante, puis par ordre lexicographique.
 * </p>
 *
 * @author Omar Ziyad Azgaoui (379136)
 * @author Mohamed Amine Goulahsen (400232)
 */
public final class StopIndex {

    private static final int FACTEUR_DEBUT_MOT = 4;
    private static final int FACTEUR_FIN_MOT = 2;
    private static final double SCORE_POURCENTAGE = 100.0;
    // Table des équivalences de lettres pour une correspondance accent-insensible
    private static final Map<Character, String> EQUIVALENT_CHARS = Map.of('c', "cç",
                                                                          'a', "aáàâä",
                                                                          'e', "eéèêë",
                                                                          'i', "iíìîï",
                                                                          'o', "oóòôö",
                                                                          'u', "uúùûü");
    // Noms principaux des arrêts (p. ex. Lausanne, Renens VD, etc.)
    private final Set<String> mainStopNames;
    // Table des alias associant un nom alternatif à son nom principal (p. ex. Losanna → Lausanne)
    private final Map<String, String> aliasToMain;

    /**
     * Construit un index des arrêts à partir de leurs noms principaux et d’un dictionnaire d’alias.
     *
     * @param stopNames la liste des noms principaux des arrêts.
     * @param aliases la table des alias, associant chaque nom alternatif à un nom principal.
     */
    public StopIndex(List<String> stopNames, Map<String, String> aliases) {
        mainStopNames = new LinkedHashSet<>(stopNames);
        aliasToMain = new LinkedHashMap<>(aliases);
    }

    /**
     * Retourne les noms des arrêts correspondant à une requête, triés par pertinence décroissante,
     * puis par ordre lexicographique, et limités au nombre maximal donné.
     * <p>
     * Une requête vide ou constituée uniquement d’espaces retourne une liste vide.
     * </p>
     *
     * @param query la requête de l’utilisateur.
     * @param maxResults le nombre maximal de résultats à retourner.
     * @return la liste des noms des arrêts correspondant à la requête.
     */
    public List<String> stopsMatching(String query, int maxResults) {
        if (query.isBlank()) return List.of();

        List<Pattern> patterns = buildQueryPatterns(query);
        Set<String> alreadyAdded = new LinkedHashSet<>();

        return Stream.concat(mainStopNames.stream(), aliasToMain.keySet().stream())
                     .map(name -> Map.entry(name, mainNameFor(name, mainStopNames, aliasToMain)))
                     .filter(e -> e.getValue() != null && mainStopNames.contains(e.getValue()))
                     .flatMap(e -> scoredMatchEntry(e.getKey(), e.getValue(), patterns))
                     .filter(e -> alreadyAdded.add(e.getKey()))
                     .sorted(Comparator.comparingInt((Map.Entry<String, Integer> e) -> -e.getValue()))
                     .limit(maxResults)
                     .map(Map.Entry::getKey)
                     .toList();
    }

    /**
     * Construit les expressions régulières à partir de la requête de l’utilisateur.
     * Chaque sous-requête est transformée en une expression insensible aux accents et,
     * si elle ne contient pas de majuscule, insensible à la casse.
     * <p>
     * Cette méthode est utilisée directement par {@code stopsMatching} pour générer les motifs
     * de recherche appliqués ensuite dans {@code scoredMatchEntry}.
     * </p>
     *
     * @param query la requête de l’utilisateur.
     * @return la liste des motifs à appliquer aux noms d’arrêts.
     */
    private static List<Pattern> buildQueryPatterns(String query) {
        return Pattern.compile("\\s+")
                      .splitAsStream(query.strip())
                      .map(subQuery -> {
                          String regex = accentInsensitiveRegex(subQuery);
                          int flags = subQuery.chars().anyMatch(Character::isUpperCase)
                                      ? 0
                                      : (CASE_INSENSITIVE | UNICODE_CASE);
                          return Pattern.compile(regex, flags);
                      })
                      .toList();
    }

    /**
     * Transforme une sous-requête en expression régulière accent-insensible.
     * <p>
     * Utilise la table {@code EQUIVALENT_CHARS} pour construire une expression
     * compatible avec toutes les variantes accentuées des lettres.
     * Appelée par {@code buildQueryPatterns} pour chaque sous-requête.
     * </p>
     *
     * @param subQuery la sous-requête à transformer.
     * @return l’expression régulière correspondante.
     */
    private static String accentInsensitiveRegex(String subQuery) {
        Pattern splitter = Pattern.compile("\\p{L}+|\\P{L}+");
        return Arrays.stream(splitter.splitWithDelimiters(subQuery, 0))
                     .flatMapToInt(String::chars)
                     .mapToObj(c -> {
                         char ch = (char) c;
                         if (Character.isLetter(ch)) {
                             String eq = EQUIVALENT_CHARS.getOrDefault(Character.toLowerCase(ch),
                                                                       String.valueOf(ch));
                             return "[" + Pattern.quote(eq) + "]";
                         } else {
                             return Pattern.quote(String.valueOf(ch));
                         }
                     })
                     .collect(Collectors.joining());
    }

    /**
     * Tente d’associer un score de pertinence à un nom (alias ou principal),
     * en retournant un flux contenant une entrée nom/score si le score est présent.
     * <p>
     * Utilisée par {@code stopsMatching} pour construire le flux d’entrées à trier.
     * Appelle {@code relevanceScore} pour l’évaluation de chaque nom.
     * </p>
     *
     * @param rawName le nom tel qu’écrit (principal ou alias).
     * @param mainName le nom principal associé.
     * @param patterns les motifs construits depuis la requête.
     * @return un flux contenant une entrée si le score existe, vide sinon.
     */
    private static Stream<Map.Entry<String, Integer>> scoredMatchEntry(String rawName,
                                                                       String mainName,
                                                                       List<Pattern> patterns) {
        OptionalInt score = relevanceScore(rawName, patterns);
        return score.isPresent()
               ? Stream.of(Map.entry(mainName, score.getAsInt()))
               : Stream.empty();
    }

    /**
     * Retourne le nom principal d’un arrêt, qu’il soit un nom officiel ou un alias.
     * <p>
     * Vérifie d’abord si le nom est principal, sinon consulte la table des alias.
     * Utilisée par {@code stopsMatching} pour garantir que seuls les noms
     * principaux sont inclus dans les résultats.
     * </p>
     *
     * @param name le nom de l’arrêt (principal ou alias).
     * @param mainStopNames l’ensemble des noms principaux.
     * @param aliasToMain la table des alias.
     * @return le nom principal correspondant, ou {@code null} si inconnu.
     */
    private static String mainNameFor(String name,
                                      Set<String> mainStopNames,
                                      Map<String, String> aliasToMain) {
        return mainStopNames.contains(name) ? name : aliasToMain.get(name);
    }

    /**
     * Calcule un score de pertinence pour un nom d’arrêt vis-à-vis d’une liste de motifs.
     * <p>
     * Un score est retourné seulement si tous les motifs sont trouvés dans le nom.
     * Cette méthode est utilisée par {@code scoredMatchEntry}.
     * </p>
     *
     * @param stopName le nom d’arrêt à tester.
     * @param patterns la liste des motifs construits à partir de la requête.
     * @return un score de pertinence, ou {@code OptionalInt.empty()} si un motif manque.
     */
    private static OptionalInt relevanceScore(String stopName, List<Pattern> patterns) {
        int totalScore = 0;
        for (Pattern pattern : patterns) {
            Matcher matcher = pattern.matcher(stopName);
            if (!matcher.find())
                return OptionalInt.empty();
            totalScore += matchScore(stopName, matcher);
        }
        return OptionalInt.of(totalScore);
    }

    /**
     * Calcule le score de correspondance d’un motif trouvé dans un nom.
     * <p>
     * Tient compte de la longueur du match par rapport au nom complet et applique
     * un multiplicateur si le match est au début ou à la fin d’un mot.
     * Utilisée exclusivement dans {@code relevanceScore}.
     * </p>
     *
     * @param stopName le nom dans lequel se trouve le motif.
     * @param matcher le résultat du motif trouvé.
     * @return le score de correspondance pondéré.
     */
    private static int matchScore(String stopName, Matcher matcher) {
        int matchLength = matcher.end() - matcher.start();
        int baseScore = (int) Math.floor(SCORE_POURCENTAGE * matchLength / stopName.length());

        int multiplier = 1;
        if (isWordStart(stopName, matcher.start()))
            multiplier *= FACTEUR_DEBUT_MOT;
        if (isWordEnd(stopName, matcher.end()))
            multiplier *= FACTEUR_FIN_MOT;

        return baseScore * multiplier;
    }

    /**
     * Indique si une position est le début d’un mot dans un texte.
     * <p>
     * Utilisée par {@code matchScore} pour déterminer si un match commence
     * en début de mot, afin de pondérer le score.
     * </p>
     *
     * @param text le texte à examiner.
     * @param pos la position à tester.
     * @return {@code true} si c’est le début d’un mot ou du texte.
     */
    private static boolean isWordStart(String text, int pos) {
        return pos == 0 || !Character.isLetter(text.charAt(pos - 1));
    }

    /**
     * Indique si une position est la fin d’un mot dans un texte.
     * <p>
     * Utilisée par {@code matchScore} pour déterminer si un match se termine
     * en fin de mot, afin de pondérer le score.
     * </p>
     *
     * @param text le texte à examiner.
     * @param pos la position à tester.
     * @return {@code true} si c’est la fin d’un mot ou du texte.
     */
    private static boolean isWordEnd(String text, int pos) {
        return pos == text.length() ||
               (pos < text.length() && !Character.isLetter(text.charAt(pos)));
    }
}