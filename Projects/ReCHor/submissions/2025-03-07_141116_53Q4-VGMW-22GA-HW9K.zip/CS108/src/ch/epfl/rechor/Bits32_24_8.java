package ch.epfl.rechor;

/**
 * Classe utilitaire non instanciable fournissant des méthodes statiques
 * permettant de manipuler des valeurs empaquetées dans un entier 32 bits.
 *
 * Elle permet de combiner deux valeurs entières, l'une sur 24 bits et l'autre sur 8 bits,
 * en un seul entier de 32 bits, ainsi que d'extraire chacune des valeurs empaquetées.
 *
 * @author Omar Ziyad Azgaoui (379136)
 * @author Mohamed Amine Goulahsen (400232)
 */
public class Bits32_24_8 {

    /**
     * Constructeur privé pour empêcher l'instanciation de la classe.
     */
    private Bits32_24_8() {}

    /**
     * Empaquette deux valeurs entières dans un seul entier de 32 bits.
     *
     * @param bits24 une valeur entière sur 24 bits (les 8 bits supérieurs doivent être à 0).
     * @param bits8 une valeur entière sur 8 bits (les bits supérieurs doivent être à 0).
     * @return un entier de 32 bits contenant les {@code bits24} dans les 24 bits de poids fort
     *         et les {@code bits8} dans les 8 bits de poids faible.
     * @throws IllegalArgumentException si {@code bits24} utilise plus de 24 bits ou {@code bits8} plus de 8 bits.
     */
    public static int pack(int bits24, int bits8) {
        Preconditions.checkArgument(bits24 >> 24 == 0 && bits8 >> 8 == 0);
        return bits24 << 8 | bits8;
    }

    /**
     * Extrait les 24 bits de poids fort d'un entier de 32 bits.
     *
     * @param bits32 l'entier de 32 bits empaqueté.
     * @return les 24 bits de poids fort.
     */
    public static int unpack24(int bits32) {
        return bits32 >> 8 & 0xFFFFFF; // Masque pour conserver un signe positif
    }

    /**
     * Extrait les 8 bits de poids faible d'un entier de 32 bits.
     *
     * @param bits32 l'entier de 32 bits empaqueté.
     * @return les 8 bits de poids faible.
     */
    public static int unpack8(int bits32) {
        return bits32 & 0xFF;
    }
}