package ch.epfl.rechor.timetable.mapped;

import ch.epfl.rechor.timetable.*;

import java.io.IOException;
import java.io.UncheckedIOException;
import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;

import static java.nio.channels.FileChannel.MapMode.READ_ONLY;

import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;

/**
 * Implémentation de {@link TimeTable} représentant un horaire de transport public dont
 * les données aplaties sont stockées dans des fichiers.
 * <p>
 * Le contenu de ces fichiers est mappé en mémoire de manière à permettre un accès rapide
 * et efficace aux données, tout en limitant la charge en mémoire.
 * <p>
 * Cette classe lit les fichiers binaires suivants du dossier donné :
 * <ul>
 *     <li>stations.bin</li>
 *     <li>station-aliases.bin</li>
 *     <li>platforms.bin</li>
 *     <li>routes.bin</li>
 *     <li>transfers.bin</li>
 *     <li>strings.txt</li>
 * </ul>
 * et, pour chaque jour, les fichiers :
 * <ul>
 *     <li>trips.bin</li>
 *     <li>connections.bin</li>
 *     <li>connections-succ.bin</li>
 * </ul>
 *
 * @param directory       le chemin vers le dossier contenant les fichiers horaires
 * @param stringTable     la table des chaînes de caractères encodées en ISO-8859-1
 * @param stations        les gares aplaties
 * @param stationAliases  les noms alternatifs des gares
 * @param platforms       les voies ou quais aplatis
 * @param routes          les lignes aplaties
 * @param transfers       les changements entre gares
 *
 * @author Omar Ziyad Azgaoui (379136)
 * @author Mohamed Amine Goulahsen (400232)
 */
public record FileTimeTable(Path directory,
                            List<String> stringTable,
                            Stations stations,
                            StationAliases stationAliases,
                            Platforms platforms,
                            Routes routes,
                            Transfers transfers)
        implements TimeTable {

    private static final DateTimeFormatter DATE_FORMATTER = DateTimeFormatter.ofPattern("yyyy-MM-dd");

    /**
     * Crée une instance de {@link FileTimeTable} à partir d’un dossier contenant les fichiers horaires.
     * <p>
     * Les fichiers doivent être organisés comme dans l’archive timetable fournie dans le projet.
     *
     * @param directory le chemin du dossier contenant les fichiers horaires
     * @return une nouvelle instance de {@link FileTimeTable}
     * @throws IOException en cas d’erreur de lecture des fichiers
     */
    public static TimeTable in(Path directory) throws IOException {
        List<String> stringTable = Files.readAllLines(directory.resolve("strings.txt"), StandardCharsets.ISO_8859_1);

        try (FileChannel stationsChannel = FileChannel.open(directory.resolve("stations.bin"));
             FileChannel stationAliChannel = FileChannel.open(directory.resolve("station-aliases.bin"));
             FileChannel platformChannel = FileChannel.open(directory.resolve("platforms.bin"));
             FileChannel routeChannel = FileChannel.open(directory.resolve("routes.bin"));
             FileChannel transferChannel = FileChannel.open(directory.resolve("transfers.bin"))) {

            ByteBuffer stationsBuffer = stationsChannel.map(READ_ONLY, 0, stationsChannel.size());
            ByteBuffer stationAliasesBuffer = stationAliChannel.map(READ_ONLY, 0, stationAliChannel.size());
            ByteBuffer platformsBuffer = platformChannel.map(READ_ONLY, 0, platformChannel.size());
            ByteBuffer routesBuffer = routeChannel.map(READ_ONLY, 0, routeChannel.size());
            ByteBuffer transferBuffer = transferChannel.map(READ_ONLY, 0, transferChannel.size());

            return new FileTimeTable(
                    directory,
                    stringTable,
                    new BufferedStations(stringTable, stationsBuffer),
                    new BufferedStationAliases(stringTable, stationAliasesBuffer),
                    new BufferedPlatforms(stringTable, platformsBuffer),
                    new BufferedRoutes(stringTable, routesBuffer),
                    new BufferedTransfers(transferBuffer)
            );
        }
    }

    /**
     * Retourne les courses de l’horaire pour une date donnée.
     *
     * @param date la date à laquelle récupérer les courses
     * @return les courses de l’horaire pour la date donnée
     * @throws UncheckedIOException si une erreur d’entrée/sortie se produit
     */
    @Override
    public Trips tripsFor(LocalDate date) {
        try {
            Path dayDirectory = directory.resolve(date.format(DATE_FORMATTER));
            Path tripsPath = dayDirectory.resolve("trips.bin");
            FileChannel tripsChannel = FileChannel.open(tripsPath);

            try (tripsChannel) {
                ByteBuffer tripsBuffer = tripsChannel.map(READ_ONLY, 0, tripsChannel.size());
                return new BufferedTrips(stringTable, tripsBuffer);
            }
        } catch (IOException e) {
            throw new UncheckedIOException(e);
        }
    }

    /**
     * Retourne les connexions de l’horaire pour une date donnée.
     *
     * @param date la date à laquelle récupérer les connexions
     * @return les connexions de l’horaire pour la date donnée
     * @throws UncheckedIOException si une erreur d’entrée/sortie se produit
     */
    @Override
    public Connections connectionsFor(LocalDate date) {
        try {
            Path dayDirectory = directory.resolve(date.format(DATE_FORMATTER));
            Path connectionsPath = dayDirectory.resolve("connections.bin");
            Path succPath = dayDirectory.resolve("connections-succ.bin");

            FileChannel connectionsChannel = FileChannel.open(connectionsPath);
            FileChannel succChannel = FileChannel.open(succPath);

            try (connectionsChannel; succChannel) {
                ByteBuffer connectionsBuffer = connectionsChannel.map(READ_ONLY, 0, connectionsChannel.size());
                ByteBuffer succBuffer = succChannel.map(READ_ONLY, 0, succChannel.size());
                return new BufferedConnections(connectionsBuffer, succBuffer);
            }
        } catch (IOException e) {
            throw new UncheckedIOException(e);
        }
    }
}
