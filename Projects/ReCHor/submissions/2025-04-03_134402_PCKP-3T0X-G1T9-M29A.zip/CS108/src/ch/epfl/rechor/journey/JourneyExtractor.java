package ch.epfl.rechor.journey;

import static ch.epfl.rechor.Bits32_24_8.unpack24;
import static ch.epfl.rechor.Bits32_24_8.unpack8;
import static ch.epfl.rechor.journey.PackedCriteria.*;
import ch.epfl.rechor.timetable.Connections;
import ch.epfl.rechor.timetable.TimeTable;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

/**
 * Classe non instanciable permettant d'extraire tous les voyages optimaux pour un arrêt de départ donné,
 * à partir d’un profil. Chaque voyage extrait contient toutes les étapes nécessaires pour atteindre la
 * gare de destination, y compris les étapes à pied initiales et finales si elles sont requises.
 * Chaque voyage est représenté sous forme d'une liste d'étapes (legs), contenant des étapes en transport
 * public et à pied, selon les besoins. Les voyages extraits respectent les critères du profil et sont triés
 * par heure de départ puis par heure d'arrivée.
 *
 * @author Omar Ziyad Azgaoui (379136)
 * @author Mohamed Amine Goulahsen (400232)
 */
public class JourneyExtractor {

    private JourneyExtractor() {
    }

    /**
     * Retourne tous les voyages optimaux pour un profil et une gare de départ donnés.
     * Les voyages sont triés par heure de départ puis par heure d'arrivée.
     */
    public static List<Journey> journeys(Profile profile, int depStationId) {
        List<Journey> journeys = new ArrayList<>();
        Connections connections = profile.connections();
        TimeTable timeTable = profile.timeTable();

        profile.forStation(depStationId).forEach(criteria -> {
            List<Journey.Leg> legs = new ArrayList<>();

            // Gérer l'extraction de voyage avec une approche itérative
            long currentCriteria = criteria;
            int initialDepId = depStationId;
            int remainingChanges = changes(currentCriteria);

            // Extraire les informations du premier critère pour vérifier si une étape à pied initiale est nécessaire
            int firstConnectionId = extractConnectionId(payload(currentCriteria));
            int firstDepStopId = connections.depStopId(firstConnectionId);
            int firstDepStationId = timeTable.stationId(firstDepStopId);

            // Ajouter une étape à pied initiale si nécessaire
            if (initialDepId != firstDepStationId) {
                int depMins = connections.depMins(firstConnectionId);
                LocalDateTime depTime = profile.date().atStartOfDay().plusMinutes(depMins);
                int transferMinutes = timeTable.transfers().minutesBetween(initialDepId, firstDepStationId);

                legs.add(new Journey.Leg.Foot(
                        createStop(profile, initialDepId),
                        depTime.minusMinutes(transferMinutes),
                        createStop(profile, firstDepStopId),
                        depTime
                ));
            }

            while (remainingChanges >= 0) {
                // Extraire les informations du critère actuel
                processLeg(profile, currentCriteria, legs, initialDepId);

                // Si plus de changements à faire, sortir de la boucle
                if (remainingChanges == 0) {
                    break;
                }

                // Trouver le prochain critère pour le prochain changement
                int targetArrMins = arrMins(currentCriteria);
                int payload = payload(currentCriteria);
                int connectionId = extractConnectionId(payload);
                int stopsToSkip = extractStopsToSkip(payload);

                // Trouver le dernier arrêt du segment actuel
                int currentConnId = connectionId;
                for (int i = 0; i < stopsToSkip; i++) {
                    currentConnId = connections.nextConnectionId(currentConnId);
                }
                int arrStopId = connections.arrStopId(currentConnId);
                int arrStationId = timeTable.stationId(arrStopId);

                // Chercher le critère suivant pour continuer le voyage
                long nextCriteria = profile.forStation(arrStationId).get(targetArrMins, remainingChanges - 1);

                // Passer au critère suivant
                currentCriteria = nextCriteria;
                remainingChanges--;
            }

            journeys.add(new Journey(legs));
        });

        journeys.sort(Comparator
                .comparing(Journey::depTime)
                .thenComparing(Journey::arrTime));

        return journeys;
    }

    /**
     * Traite une étape du voyage à partir d'un critère.
     */
    private static void processLeg(Profile profile, long criteria, List<Journey.Leg> legs, int initialDepStationId) {
        // 1. Extraire les infos du critère et connexions
        int connectionId = extractConnectionId(payload(criteria));
        int stopsToSkip = extractStopsToSkip(payload(criteria));

        Connections connections = profile.connections();
        TimeTable timeTable = profile.timeTable();

        // 2. Collecter les arrêts intermédiaires
        List<Journey.Leg.IntermediateStop> intermediateStops = new ArrayList<>();
        int currentConnId = connectionId;

        for (int i = 0; i < stopsToSkip; i++) {
            int nextConnId = connections.nextConnectionId(currentConnId);
            int stopId = connections.arrStopId(currentConnId);

            intermediateStops.add(new Journey.Leg.IntermediateStop(
                    createStop(profile, stopId),
                    profile.date().atStartOfDay().plusMinutes(connections.arrMins(currentConnId)),
                    profile.date().atStartOfDay().plusMinutes(connections.depMins(nextConnId))
            ));

            currentConnId = nextConnId;
        }

        // 3. Informations de la connexion finale
        int finalConnId = currentConnId;
        int depStopId = connections.depStopId(connectionId);
        int arrStopId = connections.arrStopId(finalConnId);
        int depMins = connections.depMins(connectionId);
        int arrMins = connections.arrMins(finalConnId);
        int tripId = connections.tripId(finalConnId);

        // 4. Créer les stops et obtenir les stations
        Stop depStop = createStop(profile, depStopId);
        Stop arrStop = createStop(profile, arrStopId);
        int depStationId = timeTable.stationId(depStopId);
        int arrStationId = timeTable.stationId(arrStopId);

        // 5. Ajouter une étape à pied entre deux transports (transfert)
        if (!legs.isEmpty() && legs.getLast() instanceof Journey.Leg.Transport lastTransport) {
            LocalDateTime lastArrTime = lastTransport.arrTime();

            // Nous avons besoin de l'ID de la station d'arrivée du dernier transport
            int fromStationId=0;
            for (int i = 0; i < timeTable.stations().size(); i++) {
                if (timeTable.stations().name(i).equals(lastTransport.arrStop().name())) {
                    fromStationId = i;
                    break;
                }
            }
            // Calculer le temps de transfert entre les deux stations
            int transferMinutes = timeTable.transfers().minutesBetween(fromStationId, depStationId);

            legs.add(new Journey.Leg.Foot(
                    lastTransport.arrStop(),
                    lastArrTime,
                    depStop,
                    lastArrTime.plusMinutes(transferMinutes)
            ));
        }

        // 6. Ajouter l'étape de transport
        legs.add(new Journey.Leg.Transport(
                depStop,
                profile.date().atStartOfDay().plusMinutes(depMins),
                arrStop,
                profile.date().atStartOfDay().plusMinutes(arrMins),
                intermediateStops,
                timeTable.routes().vehicle(profile.trips().routeId(tripId)),
                timeTable.routes().name(profile.trips().routeId(tripId)),
                profile.trips().destination(tripId)
        ));

        // 7. Ajouter une étape à pied finale si nécessaire
        int remainingChanges = changes(criteria);
        if (remainingChanges == 0 && arrStationId != profile.arrStationId()) {
            int targetStationId = profile.arrStationId();
            LocalDateTime transportArrTime = profile.date().atStartOfDay().plusMinutes(arrMins);
            int transferMinutes = timeTable.transfers().minutesBetween(arrStationId, targetStationId);

            legs.add(new Journey.Leg.Foot(
                    arrStop,
                    transportArrTime,
                    createStop(profile, targetStationId),
                    transportArrTime.plusMinutes(transferMinutes)
            ));
        }
    }

    /**
     * Crée un Stop à partir d'un ID d'arrêt.
     */
    private static Stop createStop(Profile profile, int stopId) {
        TimeTable timeTable = profile.timeTable();

        if (timeTable.isStationId(stopId)) {
            return new Stop(
                    timeTable.stations().name(stopId),
                    "",
                    timeTable.stations().longitude(stopId),
                    timeTable.stations().latitude(stopId)
            );
        } else {
            int stationId = timeTable.stationId(stopId);
            return new Stop(
                    timeTable.stations().name(stationId),
                    timeTable.platformName(stopId),
                    timeTable.stations().longitude(stationId),
                    timeTable.stations().latitude(stationId)
            );
        }
    }

    /**
     * Extrait l'ID de la connexion des 24 bits de poids fort
     */
    private static int extractConnectionId(int payload) {
        return unpack24(payload);
    }

    /**
     Extrait le nombre d'arrêts à sauter des 8 bits de poids faible
     */
    private static int extractStopsToSkip(int payload) {
        return unpack8(payload);
    }

}