package ch.epfl.rechor.gui;
import ch.epfl.rechor.journey.Vehicle;
import javafx.scene.image.Image;

import java.util.EnumMap;
import java.util.Map;

public class VehicleIcons {
    private static Map<Vehicle, Image> icons = new EnumMap<>(Vehicle.class);

    private VehicleIcons() {}

    public static Image iconFor(Vehicle vehicle) {
        return icons.computeIfAbsent(vehicle, v -> new Image(String.format("%s.png", vehicle.name())));
    }

}
