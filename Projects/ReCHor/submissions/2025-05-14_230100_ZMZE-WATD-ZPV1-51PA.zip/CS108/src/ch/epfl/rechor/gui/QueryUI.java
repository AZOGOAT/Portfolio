package ch.epfl.rechor.gui;

import ch.epfl.rechor.StopIndex;
import javafx.beans.property.ObjectProperty;
import javafx.beans.property.ReadOnlyObjectProperty;
import javafx.beans.value.ObservableValue;
import javafx.geometry.Insets;
import javafx.scene.Node;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.util.converter.LocalTimeStringConverter;

import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;

/**
 * Partie de l'interface graphique permettant à l'utilisateur de paramétrer une requête de voyage.
 * <p>
 * Cette interface permet de spécifier :
 * <ul>
 *     <li>le nom de l'arrêt de départ ;</li>
 *     <li>le nom de l'arrêt d'arrivée ;</li>
 *     <li>la date de départ souhaitée ;</li>
 *     <li>l'heure de départ souhaitée.</li>
 * </ul>
 * Les champs textuels affichent une invite en grisé lorsqu’ils sont vides. Un bouton permet d’échanger
 * les arrêts de départ et d’arrivée. La date et l’heure sont initialisées à la date et l’heure actuelles.
 * <p>
 * Le champ de l'heure permet la saisie au format « HH:mm » ou « H:mm ».
 *
 * @param rootNode   nœud JavaFX racine représentant l’interface de la requête ;
 * @param depStopO   nom observable de l’arrêt de départ ;
 * @param arrStopO   nom observable de l’arrêt d’arrivée ;
 * @param dateO      date observable du voyage ;
 * @param timeO      heure observable de départ du voyage.
 *
 * @see StopField
 * @see StopIndex
 * @author Omar Ziyad Azgaoui (379136)
 * @author Mohamed Amine Goulahsen (400232)
 */
public record QueryUI(Node rootNode,
                      ObservableValue<String> depStopO,
                      ObservableValue<String> arrStopO,
                      ObservableValue<LocalDate> dateO,
                      ObservableValue<LocalTime> timeO) {

    // Constantes liées à la mise en page
    private static final int PADDING_GENERAL = 10;
    private static final int HGAP_GRILLE = 8;
    private static final int VGAP_GRILLE = 4;
    private static final int ESPACEMENT_VBOX = 4;

    private static final DateTimeFormatter FORMAT_AFFICHAGE_HEURE = DateTimeFormatter.ofPattern("HH:mm");
    private static final DateTimeFormatter FORMAT_SAISIE_HEURE =  DateTimeFormatter.ofPattern("[H:mm][Hmm]");

    /**
     * Crée une interface utilisateur permettant de saisir les paramètres d'une requête de voyage.
     * <p>
     * Cette interface comprend deux champs textuels pour les arrêts, un bouton d’inversion entre eux,
     * ainsi qu’un sélecteur de date et un champ de saisie d’heure. Les champs sont disposés en deux lignes
     * et intégrés dans un conteneur vertical stylisé.
     *
     * @param index index des arrêts permettant de vérifier la validité des noms saisis.
     * @return une instance {@code QueryUI} représentant cette interface.
     */
    public static QueryUI create(StopIndex index) {
        // Champs d'arrêts
        StopField depField = StopField.create(index);
        depField.textField().setPromptText("Nom de l'arrêt de départ");

        StopField arrField = StopField.create(index);
        arrField.textField().setPromptText("Nom de l'arrêt d'arrivée");

        // Bouton ⟷
        Button swapButton = new Button("↔");
        swapButton.setOnAction(e -> {
            String dep = depField.textField().getText();
            String arr = arrField.textField().getText();
            depField.setTo(arr);
            arrField.setTo(dep);
        });

        // Ligne 1 : Arrêts
        GridPane stopGrid = createSingleRowGrid(
                new Label("Départ\u202f:"), depField.textField(),
                swapButton,
                new Label("Arrivée\u202f:"), arrField.textField()
                                                 );

        GridPane.setValignment(swapButton, javafx.geometry.VPos.CENTER);
        swapButton.setMaxHeight(Double.MAX_VALUE);
        swapButton.setMinHeight(Region.USE_PREF_SIZE);

        // Champs date/heure
        DatePicker datePicker = new DatePicker(LocalDate.now());
        datePicker.setShowWeekNumbers(false);
        ObjectProperty<LocalDate> dateProperty = datePicker.valueProperty();

        LocalTimeStringConverter converter = new LocalTimeStringConverter(
                FORMAT_AFFICHAGE_HEURE, FORMAT_SAISIE_HEURE);
        TextField timeField = new TextField();
        LocalTime currentTimeTrimmed = LocalTime.now().withSecond(0).withNano(0);

        TextFormatter<LocalTime> timeFormatter = new TextFormatter<>(converter, currentTimeTrimmed);
        timeField.setTextFormatter(timeFormatter);
        ReadOnlyObjectProperty<LocalTime> timeProperty = timeFormatter.valueProperty();

        // Ligne 2 : Date et Heure
        GridPane dateGrid = createSingleRowGrid(
                new Label("Date\u202f:"), datePicker,
                new Label("Heure\u202f:"), timeField
                                                 );
        dateGrid.setPadding(new Insets(0, PADDING_GENERAL, PADDING_GENERAL, PADDING_GENERAL));

        // Racine
        VBox root = new VBox(ESPACEMENT_VBOX , stopGrid, dateGrid);
        root.setId("query");
        root.getStylesheets().add("query.css");

        return new QueryUI(root, depField.stopO(), arrField.stopO(), dateProperty, timeProperty);
    }

    /**
     * Construit une ligne de formulaire (grille) contenant les nœuds fournis, en les plaçant horizontalement.
     * <p>
     * Cette méthode facilite la construction des lignes composant l’interface, en appliquant une
     * configuration homogène de marges et d’espacement.
     *
     * @param alternatingNodes les nœuds à placer dans la ligne, de gauche à droite.
     * @return une grille contenant les nœuds, avec espacement et marges appliqués.
     */
    private static GridPane createSingleRowGrid(Node... alternatingNodes) {
        GridPane grid = new GridPane();
        grid.setHgap(HGAP_GRILLE);
        grid.setVgap(VGAP_GRILLE);
        grid.setPadding(new Insets(PADDING_GENERAL));

        int columnIndex = 0;
        for (Node node : alternatingNodes) {
            grid.add(node, columnIndex++, 0);
        }
        return grid;
    }
}