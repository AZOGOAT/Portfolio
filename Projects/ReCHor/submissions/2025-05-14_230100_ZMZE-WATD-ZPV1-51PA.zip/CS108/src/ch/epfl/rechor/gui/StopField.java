package ch.epfl.rechor.gui;

import ch.epfl.rechor.StopIndex;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Bounds;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import javafx.scene.input.KeyEvent;
import javafx.stage.Popup;

import java.util.List;

/**
 * Représente la combinaison d’un champ textuel et d’une fenêtre, qui permet de choisir un arrêt de transport public.
 * Le champ textuel permet de saisir une requête et la fenêtre affiche dynamiquement les 30 meilleurs résultats de recherche d’arrêt,
 * triés par pertinence. Le premier résultat est sélectionné initialement. La sélection peut se faire par la souris ou la touche "entrée"
 * tandis que les touches ↑ et ↓ permettent le "déplacement" dans la barre de recherche.
 * Lorsque le champ textuel devient inactif (perte de focus), le texte est remplacé par le résultat sélectionné s’il y en a un, ou vidé sinon.
 *
 * @param textField le champ textuel associé
 * @param stopO la valeur observable contenant le nom de l'arrêt sélectionné ou une chaîne vide si aucun n'est sélectionné
 *
 * @author Omar Ziyad Azgaoui (379136)
 * @author Mohamed Amine Goulahsen (400232)
 */
public record StopField(TextField textField, ObservableValue<String> stopO) {

    private static final double HAUTEUR_LISTE_ARRETS = 240;
    private static final int MAX_RESULTATS_ARRETS = 30;

    /**
     * Crée un champ de recherche d'arrêt graphique permettant la sélection d'un arrêt parmi ceux présents dans l'index.
     * Affiche dynamiquement les meilleurs résultats sous forme de liste au fur et à mesure de la saisie.
     * La valeur observable associée contient le nom de l'arrêt sélectionné, ou une chaîne vide si aucun n'est sélectionné.
     *
     * @param index l’index des arrêts à utiliser pour effectuer la recherche
     * @return une instance de {@code StopField} initialisée
     */
    public static StopField create(StopIndex index) {
        TextField textField = new TextField();
        StringProperty selectedStop = new SimpleStringProperty("");

        ListView<String> listView = new ListView<>();
        listView.setFocusTraversable(false);
        listView.setMaxHeight(HAUTEUR_LISTE_ARRETS);

        Popup popup = new Popup();
        popup.setAutoHide(true);
        popup.setHideOnEscape(false);
        popup.getContent().add(listView);

        listView.setOnMouseClicked(e -> {
            String selected = listView.getSelectionModel().getSelectedItem();
            if (selected != null) {
                textField.setText(selected);
                selectedStop.set(selected);
                popup.hide();
            }
        });


        // Listener qui met à jour les résultats de la recherche quand le texte change
        ChangeListener<String> textListener = (obs, oldVal, newVal) -> {
            updateList(index, newVal, listView);
            if (!popup.isShowing() && textField.isFocused()) {
                showPopup(popup, textField);
            }
        };

        // Listener qui repositionne dynamiquement le popup selon la position du champ
        ChangeListener<Bounds> boundsListener = (obs, oldVal, newVal) ->
                repositionPopup(popup, textField);

        // Gestion du focus pour afficher/masquer le popup et gérer la sélection
        textField.focusedProperty().addListener((obs, oldFocused, newFocused) -> {
            if (newFocused) {
                updateList(index, textField.getText(), listView);
                showPopup(popup, textField);

                textField.textProperty().addListener(textListener);
                textField.boundsInLocalProperty().addListener(boundsListener);
            } else {
                popup.hide();
                textField.textProperty().removeListener(textListener);
                textField.boundsInLocalProperty().removeListener(boundsListener);

                String currentText = textField.getText().strip();
                textField.setText(currentText);
                selectedStop.set(currentText);
            }
        });

        // Gestion des touches ↑ et ↓ pour naviguer dans les suggestions
        textField.addEventHandler(KeyEvent.KEY_PRESSED, event -> {
            switch (event.getCode()) {
                case UP -> {
                    moveSelection(listView, false);
                    event.consume();
                }
                case DOWN -> {
                    moveSelection(listView, true);
                    event.consume();
                }
                case ENTER -> {
                    String selected = listView.getSelectionModel().getSelectedItem();
                    if (selected != null) {
                        textField.setText(selected);
                        selectedStop.set(selected);
                    }
                    popup.hide();
                    event.consume();
                }
            }
        });

        textField.setOnMouseClicked(e -> {
            if (!popup.isShowing() && textField.isFocused()) {
                updateList(index, textField.getText(), listView);
                showPopup(popup, textField);
            }
        });

        return new StopField(textField, selectedStop);
    }

    /**
     * Modifie le texte du champ textuel associé à ce {@code StopField}.
     *
     * @param stopName le nom de l'arrêt à afficher dans le champ textuel
     */
    public void setTo(String stopName) {
        textField.setText(stopName);
        // Mettre aussi à jour directement la valeur observable
        if (stopO instanceof StringProperty sp) {
            sp.set(stopName);
        }
    }

    /**
     * Met à jour la liste des suggestions affichées dans le {@code ListView} à partir de la requête entrée.
     *
     * @param index l’index des arrêts
     * @param query la chaîne de caractères tapée par l’utilisateur
     * @param listView la liste des résultats à mettre à jour
     */
    private static void updateList(StopIndex index, String query, ListView<String> listView) {
        List<String> results = index.stopsMatching(query, MAX_RESULTATS_ARRETS);
        ObservableList<String> items = FXCollections.observableArrayList(results);
        listView.setItems(items);
        if (!items.isEmpty())
            listView.getSelectionModel().selectFirst();
    }

    /**
     * Affiche le popup contenant la liste des suggestions sous le champ textuel.
     *
     * @param popup le popup à afficher
     * @param tf le champ textuel de référence
     */
    private static void showPopup(Popup popup, TextField tf) {
        Bounds screenBounds = tf.localToScreen(tf.getBoundsInLocal());
        popup.show(tf, screenBounds.getMinX(), screenBounds.getMaxY());
    }

    /**
     * Repositionne dynamiquement le popup selon la position du champ textuel.
     *
     * @param popup le popup à repositionner
     * @param tf le champ textuel de référence
     */
    private static void repositionPopup(Popup popup, TextField tf) {
        if (!popup.isShowing()) return;
        Bounds screenBounds = tf.localToScreen(tf.getBoundsInLocal());
        popup.setAnchorX(screenBounds.getMinX());
        popup.setAnchorY(screenBounds.getMaxY());
    }

    /**
     * Modifie la sélection actuelle dans la liste selon la direction spécifiée.
     *
     * @param listView la liste des suggestions
     * @param directionDown {@code true} pour aller vers le bas, {@code false} pour aller vers le haut
     */
    private static void moveSelection(ListView<String> listView, boolean directionDown) {
        int i = listView.getSelectionModel().getSelectedIndex();
        int itemCount = listView.getItems().size();
        int newIndex = directionDown ? i + 1 : i - 1;

        if ((directionDown && i < itemCount - 1) || (!directionDown && i > 0)) {
            listView.getSelectionModel().select(newIndex);
            listView.scrollTo(newIndex);
        }
    }
}