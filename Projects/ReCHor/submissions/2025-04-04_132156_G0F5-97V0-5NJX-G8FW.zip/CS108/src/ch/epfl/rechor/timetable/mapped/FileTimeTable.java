package ch.epfl.rechor.timetable.mapped;

import ch.epfl.rechor.timetable.*;

import java.io.IOException;
import java.io.UncheckedIOException;
import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;

import static java.nio.channels.FileChannel.MapMode.READ_ONLY;

import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.LocalDate;
import java.util.List;

/**
 * Implémentation de {@link TimeTable} représentant un horaire de transport public dont
 * les données aplaties sont stockées dans des fichiers.
 * <p>
 * Le contenu de ces fichiers est mappé en mémoire de manière à permettre un accès rapide
 * et efficace aux données, tout en limitant la charge en mémoire.
 * <p>
 * Cette classe lit les fichiers binaires suivants du dossier donné :
 * <ul>
 *     <li>stations.bin</li>
 *     <li>station-aliases.bin</li>
 *     <li>platforms.bin</li>
 *     <li>routes.bin</li>
 *     <li>transfers.bin</li>
 *     <li>strings.txt</li>
 * </ul>
 * et, pour chaque jour, les fichiers :
 * <ul>
 *     <li>trips.bin</li>
 *     <li>connections.bin</li>
 *     <li>connections-succ.bin</li>
 * </ul>
 *
 * @param directory       le chemin vers le dossier contenant les fichiers horaires
 * @param stringTable     la table des chaînes de caractères encodées en ISO-8859-1
 * @param stations        les gares aplaties
 * @param stationAliases  les noms alternatifs des gares
 * @param platforms       les voies ou quais aplatis
 * @param routes          les lignes aplaties
 * @param transfers       les changements entre gares
 *
 * @author Omar Ziyad Azgaoui (379136)
 * @author Mohamed Amine Goulahsen (400232)
 */
public record FileTimeTable(Path directory,
                            List<String> stringTable,
                            Stations stations,
                            StationAliases stationAliases,
                            Platforms platforms,
                            Routes routes,
                            Transfers transfers)
        implements TimeTable {

    private static final String STRINGS_FILE = "strings.txt";
    private static final String STATIONS_FILE = "stations.bin";
    private static final String STATION_ALIASES_FILE = "station-aliases.bin";
    private static final String PLATFORMS_FILE = "platforms.bin";
    private static final String ROUTES_FILE = "routes.bin";
    private static final String TRANSFERS_FILE = "transfers.bin";
    private static final String TRIPS_FILE = "trips.bin";
    private static final String CONNECTIONS_FILE = "connections.bin";
    private static final String CONNECTIONS_SUCC_FILE = "connections-succ.bin";

    /**
     * Crée une instance de {@link FileTimeTable} à partir d’un dossier contenant les fichiers horaires.
     * <p>
     * Les fichiers doivent être organisés comme dans l’archive timetable fournie dans le projet.
     *
     * @param directory le chemin du dossier contenant les fichiers horaires
     * @return une nouvelle instance de {@link FileTimeTable}
     * @throws IOException en cas d’erreur de lecture des fichiers
     */
    public static TimeTable in(Path directory) throws IOException {
        Path path = directory.resolve(STRINGS_FILE);
        Charset cs = StandardCharsets.ISO_8859_1;
        List<String> stringTable = List.copyOf(Files.readAllLines(path, cs));

        try (FileChannel stationsChannel = openChannel(directory, STATIONS_FILE);
             FileChannel stationAliChannel = openChannel(directory, STATION_ALIASES_FILE);
             FileChannel platformChannel = openChannel(directory, PLATFORMS_FILE);
             FileChannel routeChannel = openChannel(directory, ROUTES_FILE);
             FileChannel transferChannel = openChannel(directory, TRANSFERS_FILE)) {

            ByteBuffer stationsBuffer = mapFile(stationsChannel);
            ByteBuffer stationAliasesBuffer = mapFile(stationAliChannel);
            ByteBuffer platformsBuffer = mapFile(platformChannel);
            ByteBuffer routesBuffer = mapFile(routeChannel);
            ByteBuffer transferBuffer = mapFile(transferChannel);

            return new FileTimeTable(
                    directory,
                    stringTable,
                    new BufferedStations(stringTable, stationsBuffer ),
                    new BufferedStationAliases(stringTable, stationAliasesBuffer ),
                    new BufferedPlatforms(stringTable, platformsBuffer ),
                    new BufferedRoutes(stringTable, routesBuffer ),
                    new BufferedTransfers(transferBuffer )
            );
        }
    }

    /**
     * Retourne les courses de l’horaire pour une date donnée.
     *
     * @param date la date à laquelle récupérer les courses
     * @return les courses de l’horaire pour la date donnée
     * @throws UncheckedIOException si une erreur d’entrée/sortie se produit
     */
    @Override
    public Trips tripsFor(LocalDate date) {
        try {
            Path dayDirectory = directory.resolve(date.toString());
            FileChannel tripsChannel = openChannel(dayDirectory, TRIPS_FILE);

            try (tripsChannel) {
                ByteBuffer tripsBuffer = mapFile(tripsChannel);
                return new BufferedTrips(stringTable, tripsBuffer);
            }
        } catch (IOException e) {
            throw new UncheckedIOException(e);
        }
    }

    /**
     * Retourne les connexions de l’horaire pour une date donnée.
     *
     * @param date la date à laquelle récupérer les connexions
     * @return les connexions de l’horaire pour la date donnée
     * @throws UncheckedIOException si une erreur d’entrée/sortie se produit
     */
    @Override
    public Connections connectionsFor(LocalDate date) {
        try {
            Path dayDirectory = directory.resolve(date.toString());
            FileChannel connectionsChannel = openChannel(dayDirectory, CONNECTIONS_FILE);
            FileChannel succChannel = openChannel(dayDirectory, CONNECTIONS_SUCC_FILE);

            try (connectionsChannel; succChannel) {
                ByteBuffer connectionsBuffer = mapFile(connectionsChannel);
                ByteBuffer succBuffer = mapFile(succChannel);
                return new BufferedConnections(connectionsBuffer, succBuffer);
            }
        } catch (IOException e) {
            throw new UncheckedIOException(e);
        }
    }

    /**
     * Ouvre un canal de lecture vers un fichier situé dans un dossier donné.
     * <p>
     * Cette méthode résout le chemin du fichier à partir du dossier fourni,
     * puis retourne un {@link FileChannel} permettant d'accéder à son contenu.
     * Le canal doit être fermé à l'aide d'un bloc {@code try-with-resources}.
     *
     * @param directory le répertoire contenant le fichier
     * @param fileName  le nom du fichier à ouvrir
     * @return un canal permettant d’accéder au fichier en lecture seule
     * @throws IOException si le fichier est introuvable ou ne peut pas être ouvert
     */
    private static FileChannel openChannel(Path directory, String fileName) throws IOException {
        return FileChannel.open(directory.resolve(fileName));
    }

    /**
     * Mappe un fichier entier en mémoire.
     *
     * @param channel le canal du fichier ouvert
     * @return un ByteBuffer contenant les données mappées en mémoire
     * @throws IOException en cas d’erreur lors du mapping
     */
    private static ByteBuffer mapFile(FileChannel channel) throws IOException {
        return channel.map(READ_ONLY, 0, channel.size());
    }
}