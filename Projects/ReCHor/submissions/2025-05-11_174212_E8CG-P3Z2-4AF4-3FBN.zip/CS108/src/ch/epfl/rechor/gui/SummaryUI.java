package ch.epfl.rechor.gui;

import ch.epfl.rechor.FormatterFr;
import ch.epfl.rechor.journey.Journey;
import javafx.beans.value.ObservableValue;
import javafx.scene.Group;
import javafx.scene.Node;
import javafx.scene.control.ListCell;
import javafx.scene.control.ListView;
import javafx.scene.image.ImageView;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Line;
import javafx.scene.text.Text;

import java.time.LocalTime;
import java.util.List;

import static ch.epfl.rechor.gui.VehicleIcons.iconFor;
import static java.time.Duration.between;

public record SummaryUI(Node rootNode, ObservableValue<Journey> selectedJourney0) {
    public static SummaryUI create(ObservableValue<List<Journey>> displayJourneys0,
                                   ObservableValue<LocalTime> journeyTime) {
        List<Journey> journeyList = displayJourneys0.getValue();

        Journey found = journeyList
                .stream()
                .filter(j -> !j.depTime().toLocalTime().isBefore(journeyTime.getValue()))
                .findFirst()
                .orElseGet(() -> journeyList.isEmpty() ? null : journeyList.getLast());

        ListView<Journey> summaryList = new ListView<>();
        summaryList.getStylesheets().add("summary.css");
        summaryList.setCellFactory(lv -> new MyListCell());
        summaryList.getItems().addAll(journeyList);

        if (found != null) {
            summaryList.getSelectionModel().select(found);
        }

        return new SummaryUI(summaryList, summaryList.getSelectionModel().selectedItemProperty());
    }

    private static class MyListCell extends ListCell<Journey> {
        private final Line changeLinePath = new Line();
        private final Group changeLineDots = new Group();
        private final Pane changeLine = new Pane();
        private final Circle startCircle = new Circle(3);
        private final Circle endCircle   = new Circle(3);

        public MyListCell() {
            super();

            // Style du Pane central
            changeLine.getStyleClass().add("changes");
            changeLine.setPrefSize(0, 0);

            // On ajoute dans l'ordre : la ligne, les points de transfert, puis les cercles de départ/arrivée
            changeLine.getChildren().addAll(
                    changeLinePath,
                    changeLineDots,
                    startCircle,
                    endCircle
            );

            // Style des cercles "départ/arrivée"
            startCircle.getStyleClass().add("dep-arr");
            endCircle  .getStyleClass().add("dep-arr");
        }

        @Override
        protected void updateItem(Journey journey, boolean empty) {
            super.updateItem(journey, empty);
            if (empty || journey == null) {
                setGraphic(null);
                return;
            }

            // ─── Top : ligne / direction ────────────────────────────────────────────────
            Journey.Leg firstLeg = journey.legs().getFirst();
            if (!(firstLeg instanceof Journey.Leg.Transport)) {
                // si la première étape est à pied, on prend la deuxième
                firstLeg = journey.legs().get(1);
            }
            Journey.Leg.Transport firstTr = (Journey.Leg.Transport) firstLeg;

            HBox route = new HBox(5);
            route.getStyleClass().add("route");
            ImageView icon = new ImageView(iconFor(firstTr.vehicle()));
            icon.setFitWidth(20);
            icon.setFitHeight(20);
            icon.setPreserveRatio(true);
            Text routeText = new Text(firstTr.route() + " Direction " + firstTr.destination());
            route.getChildren().setAll(icon, routeText);

            // ─── Left : heure de départ ────────────────────────────────────────────────
            Text depTime = new Text(FormatterFr.formatTime(journey.depTime()));
            depTime.getStyleClass().add("departure");

            // ─── Right : heure d'arrivée ───────────────────────────────────────────────
            Text arrTime = new Text(FormatterFr.formatTime(journey.arrTime()));
            arrTime.getStyleClass().add("arrival");

            // ─── Center : la ligne de changements ──────────────────────────────────────
            changeLineDots.getChildren().clear();
            long totalMin = journey.duration().toMinutes();
            for (Journey.Leg leg : journey.legs()) {
                if (leg instanceof Journey.Leg.Foot foot && foot.isTransfer()) {
                    long minutesSinceDep = between(journey.depTime(), foot.depTime())
                            .toMinutes();
                    double frac = (double) minutesSinceDep / totalMin;
                    Circle c = new Circle(3);
                    c.setUserData(frac);
                    c.getStyleClass().add("transfer");
                    changeLineDots.getChildren().add(c);
                }
            }

            // forcer le layout du Pane pour positionner tout
            changeLine.layout();

            // ─── Bottom : durée totale ────────────────────────────────────────────────
            HBox duration = new HBox();
            duration.getStyleClass().add("duration");
            Text durText = new Text(FormatterFr.formatDuration(journey.duration()));
            duration.getChildren().setAll(durText);

            // ─── Assemblage BorderPane ────────────────────────────────────────────────
            BorderPane root = new BorderPane();
            root.getStyleClass().add("journey");
            root.setTop(route);
            root.setLeft(depTime);
            root.setCenter(changeLine);
            root.setRight(arrTime);
            root.setBottom(duration);

            setGraphic(root);
        }

        // on override pour forcer le calcul des positions à chaque mise à jour
        @Override
        protected void layoutChildren() {
            super.layoutChildren();
            double w       = changeLine.getWidth();
            double h       = changeLine.getHeight();
            double startX  = 5;
            double endX    = w - 5;
            double centerY = h / 2;

            changeLinePath.setStartX(startX);
            changeLinePath.setStartY(centerY);
            changeLinePath.setEndX(endX);
            changeLinePath.setEndY(centerY);

            startCircle.setCenterX(startX);
            startCircle.setCenterY(centerY);
            endCircle  .setCenterX(endX);
            endCircle  .setCenterY(centerY);

            for (Node node : changeLineDots.getChildren()) {
                Circle c = (Circle) node;
                double frac = (Double) c.getUserData();
                double x = startX + frac * (endX - startX);
                c.getStyleClass().add("transfer");
                c.setCenterX(x);
                c.setCenterY(centerY);
            }
        }
    }
}
