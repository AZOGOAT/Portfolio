package ch.epfl.rechor.journey;

import ch.epfl.rechor.timetable.Connections;
import ch.epfl.rechor.timetable.TimeTable;
import ch.epfl.rechor.timetable.Trips;
import java.time.LocalDate;
import java.util.List;

public final record Profile(TimeTable timeTable,
                            LocalDate date,
                            int arrStationId,
                            List<ParetoFront> stationFront) {
    public Profile{
        stationFront = List.copyOf(stationFront);
    }

    public Connections connections(){
        return timeTable.connectionsFor(date);
    }

    public Trips trips(){
        return timeTable.tripsFor(date);
    }

    public ParetoFront forStation(int stationId){
        if(stationId<stationFront.size()&&stationId>=0){
            return stationFront.get(stationId);
        }
        else throw new IndexOutOfBoundsException("Station non trouvée");
    }

    public static final class Builder {
        private final TimeTable timeTable;
        private final LocalDate date;
        private final int arrStationId;
        private final int stationSize;
        private final int tripsSize;
        private final ParetoFront.Builder[] stationFrontBuilder;
        private final ParetoFront.Builder[] tripsFront;

        public Builder(TimeTable timeTable, LocalDate date, int arrStationId){
            this.timeTable = timeTable;
            this.date = date;
            this.arrStationId = arrStationId;
            this.stationSize = timeTable.stations().size();
            this.tripsSize = timeTable.tripsFor(date).size();
            this.stationFrontBuilder = new ParetoFront.Builder[stationSize];
            this.tripsFront = new ParetoFront.Builder[tripsSize];
        }

        public ParetoFront.Builder forStation(int stationId){
            if(stationId < stationSize && stationId >= 0){
                return stationFrontBuilder[stationId];
            }
            throw new IndexOutOfBoundsException("Index invalide");
        }

        public void setForStation(int stationId, ParetoFront.Builder builder){
            if(stationId < stationSize && stationId >= 0){
                stationFrontBuilder[stationId] = builder;
            } else {
                throw new IndexOutOfBoundsException("Index invalide");
            }
        }

        public ParetoFront.Builder forTrip(int tripId){
            if(tripId < tripsSize && tripId >= 0){
                return tripsFront[tripId];
            }
            throw new IndexOutOfBoundsException("Index invalide");
        }

        public void setForTrip(int tripId, ParetoFront.Builder builder){
            if(tripId < tripsSize && tripId >= 0){
                tripsFront[tripId] = builder;
            } else {
                throw new IndexOutOfBoundsException("Index invalide");
            }
        }

        public Profile build(){
            ParetoFront[] stationFront = new ParetoFront[stationSize];

            // Remplir le tableau avec des frontières vides ou construites
            for(int i = 0; i < stationSize; i++) {
                ParetoFront.Builder builder = stationFrontBuilder[i];
                stationFront[i] = (builder != null) ? builder.build() : ParetoFront.EMPTY;
            }

            return new Profile(
                    this.timeTable,
                    this.date,
                    this.arrStationId,
                    List.of(stationFront)
            );
        }
    }
}
