package ch.epfl.rechor.gui;

import ch.epfl.rechor.StopIndex;
import javafx.beans.property.SimpleObjectProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.geometry.Bounds;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import javafx.scene.input.KeyEvent;
import javafx.stage.Popup;
import javafx.util.Subscription;

import java.util.List;

/**
 * Représente la combinaison d’un champ textuel et d’une fenêtre, qui permet de choisir un arrêt de transport public.
 * Le champ textuel permet de saisir une requête et la fenêtre affiche dynamiquement les 30 meilleurs résultats de recherche d’arrêt,
 * triés par pertinence. Le premier résultat est sélectionné initialement. La sélection se fait par la touche tabulation
 * tandis que les touches ↑ et ↓ permettent le "déplacement" dans la barre de recherche.
 * Lorsque le champ textuel devient inactif (perte de focus), le texte est remplacé par le résultat sélectionné s’il y en a un, ou vidé sinon.
 *
 * @param textField le champ textuel, de type {@code TextField}
 * @param stopO une valeur observable contenant le nom de l'arrêt sélectionné, ou une chaîne vide si aucun arrêt ne correspond à la requête
 *
 * @author Omar Ziyad Azgaoui (379136)
 * @author Mohamed Amine Goulahsen (400232)
 */
public record StopField(TextField textField, ObservableValue<String> stopO) {

    private static final double HAUTEUR_LISTE_ARRETS = 240;
    private static final int MAX_RESULTATS_ARRETS = 30;

    /**
     * Crée un champ textuel et une fenêtre permettant de choisir un arrêt de transport public à partir d'un index.
     * La valeur observable retournée contient le nom de l'arrêt sélectionné ou une chaîne vide si aucun n'est sélectionné.
     *
     * @param index l’index des arrêts à utiliser pour rechercher les arrêts
     * @return une instance de {@code StopField} initialisée
     */
    public static StopField create(StopIndex index) {
        TextField textField = new TextField();
        StringProperty selectedStop = new SimpleStringProperty("");

        ListView<String> listView = new ListView<>();
        listView.setFocusTraversable(false);
        listView.setMaxHeight(HAUTEUR_LISTE_ARRETS);

        Popup popup = new Popup();
        popup.setHideOnEscape(false);
        popup.getContent().add(listView);

        // Observers dynamiques (créés au gain de focus, supprimés à la perte)
        SimpleObjectProperty<Subscription> textSubscription = new SimpleObjectProperty<>();
        SimpleObjectProperty<Subscription> boundsSubscription = new SimpleObjectProperty<>();

        // ↑ / ↓ navigation dans la liste
        textField.addEventHandler(KeyEvent.KEY_PRESSED, event -> {
            switch (event.getCode()) {
                case UP -> {
                    int i = listView.getSelectionModel().getSelectedIndex();
                    if (i > 0) {
                        listView.getSelectionModel().select(i - 1);
                        listView.scrollTo(i - 1);
                        event.consume();
                    }
                }
                case DOWN -> {
                    int i = listView.getSelectionModel().getSelectedIndex();
                    if (i < listView.getItems().size() - 1) {
                        listView.getSelectionModel().select(i + 1);
                        listView.scrollTo(i + 1);
                        event.consume();
                    }
                }
            }
        });

        // Gestion de Focus
        textField.focusedProperty().subscribe(focused -> {
            if (focused) {
                // Observer text → update list
                textSubscription.set(textField.textProperty().subscribe(text -> {
                    String query = text.isBlank() ? "aa" : text;
                    List<String> results = index.stopsMatching(query, MAX_RESULTATS_ARRETS);
                    listView.setItems(FXCollections.observableArrayList(results));
                    if (!results.isEmpty())
                        listView.getSelectionModel().selectFirst();
                }));

                // Observer bounds → reposition popup dynamiquement
                boundsSubscription.set(textField.boundsInLocalProperty().subscribe(_ -> {
                    Bounds b = textField.localToScreen(textField.getBoundsInLocal());
                    popup.setAnchorX(b.getMinX());
                    popup.setAnchorY(b.getMaxY());
                }));

                // Mise à jour initiale
                String query = textField.getText().isBlank() ? "aa" : textField.getText();
                List<String> results = index.stopsMatching(query, MAX_RESULTATS_ARRETS);
                listView.setItems(FXCollections.observableArrayList(results));
                if (!results.isEmpty()) listView.getSelectionModel().selectFirst();

                // Positionner et afficher popup
                Bounds b = textField.localToScreen(textField.getBoundsInLocal());
                popup.show(textField, b.getMinX(), b.getMaxY());
            } else {
                // À la perte de focus : copier la sélection ou vider
                popup.hide();
                if (textSubscription.get() != null) textSubscription.get().unsubscribe();
                if (boundsSubscription.get() != null) boundsSubscription.get().unsubscribe();

                String selected = listView.getSelectionModel().getSelectedItem();
                if (selected != null) {
                    textField.setText(selected);
                    selectedStop.set(selected);
                } else {
                    textField.clear();
                    selectedStop.set("");
                }
            }
        });

        return new StopField(textField, selectedStop);
    }

    /**
     * Met à jour le champ textuel associé avec le nom de l'arrêt donné.
     *
     * @param stopName le nom de l'arrêt à afficher dans le champ textuel
     */
    public void setTo(String stopName) {
        textField.setText(stopName);
        // Mettre aussi à jour directement la valeur observable
        if (stopO instanceof StringProperty sp) {
            sp.set(stopName);
        }
    }
}