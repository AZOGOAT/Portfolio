package ch.epfl.rechor.gui;

import ch.epfl.rechor.StopIndex;
import ch.epfl.rechor.journey.*;
import ch.epfl.rechor.timetable.*;
import ch.epfl.rechor.timetable.mapped.FileTimeTable;
import javafx.application.Application;
import javafx.application.Platform;
import javafx.beans.binding.Bindings;
import javafx.beans.binding.ObjectBinding;
import javafx.beans.property.ObjectProperty;
import javafx.beans.property.SimpleObjectProperty;
import javafx.beans.value.ObservableValue;
import javafx.scene.Scene;
import javafx.scene.control.SplitPane;
import javafx.scene.layout.BorderPane;
import javafx.stage.Stage;

import java.nio.file.Path;
import java.time.LocalDate;
import java.util.*;

/**
 * Classe principale du programme ReCHor.
 * <p>
 * Combine les différentes parties de l’interface graphique développées dans les étapes précédentes.
 * Permet à un utilisateur d’entrer les paramètres d’un voyage (arrêt de départ, arrêt d’arrivée,
 * date et heure) et d’afficher les résultats correspondants dans deux vues synchronisées : la vue d’ensemble
 * des voyages disponibles et la vue détaillée du voyage sélectionné.
 *
 * @author Omar Ziyad Azgaoui (379136)
 * @author Mohamed Amine Goulahsen (400232)
 */
public final class Main extends Application {

    private static final int LARGEUR_MINIMALE = 800;
    private static final int HAUTEUR_MINIMALE = 600;

    private ObjectBinding<List<Journey>> journeysB;

    /**
     * Point d’entrée du programme.
     *
     * @param args les arguments passés au programme (ignorés).
     */
    public static void main(String[] args) {
        launch(args);
    }

    /**
     * Méthode appelée au lancement de l'application JavaFX.
     *
     * @param primaryStage la scène principale.
     * @throws Exception en cas d’erreur lors de l’initialisation.
     */
    @Override
    public void start(Stage primaryStage) throws Exception {
        // Création de l’horaire en mémoire depuis les fichiers aplatis
        TimeTable timeTable = new CachedTimeTable(FileTimeTable.in(Path.of("timetable/timetable 20")));

        Stations stations = timeTable.stations();
        StationAliases aliases = timeTable.stationAliases();

        // Construction de l’index des arrêts pour la recherche
        StopIndex stopIndex = buildStopIndex(stations, aliases);

        // Création de l’interface de requête
        QueryUI queryUI = QueryUI.create(stopIndex);
        queryUI.rootNode().lookupAll(".text-field").stream()
               .findFirst().ifPresent(node -> node.setId("depStop")); // pour focus initial

        // Observation des champs de recherche
        ObservableValue<String> depStopO = queryUI.depStopO();
        ObservableValue<String> arrStopO = queryUI.arrStopO();
        ObservableValue<LocalDate> dateO = queryUI.dateO();
        ObservableValue<java.time.LocalTime> timeO = queryUI.timeO();

        Router router = new Router(timeTable);

        // Liaison dynamique : calcule les voyages à partir des entrées utilisateu
            journeysB = Bindings.createObjectBinding(() -> {
            String depStop = depStopO.getValue();
            String arrStop = arrStopO.getValue();
            LocalDate date = dateO.getValue();

            if (depStop.isBlank() || arrStop.isBlank())
                return List.of();

            int depId = stationId(stations, depStop);
            int arrId = stationId(stations, arrStop);
            Profile profile = router.profile(date, arrId);

            return JourneyExtractor.journeys(profile, depId);
        }, depStopO, arrStopO, dateO);

        ObjectProperty<List<Journey>> journeysP = new SimpleObjectProperty<>();
        journeysB.addListener((obs, oldV, newV) -> journeysP.set(newV));

        // Initialisation des composants graphiques
        ObjectProperty<SummaryUI> summaryUIP = new SimpleObjectProperty<>();
        ObjectProperty<DetailUI> detailUIP = new SimpleObjectProperty<>();

        BorderPane root = new BorderPane();
        root.setTop(queryUI.rootNode());

        // Vue initiale sans voyage
        SplitPane initialSplit = createJourneySplit(List.of(), timeO, summaryUIP, detailUIP);
        root.setCenter(initialSplit);

        // Met à jour la vue à chaque changement dans les voyages
        journeysP.addListener((obs, oldV, newV) -> {
            if (shouldSkip(newV) || Objects.equals(oldV, newV)) return;
            Platform.runLater(() -> root.setCenter(createJourneySplit(newV, timeO, summaryUIP, detailUIP)));
        });

        // Met à jour la sélection si l'heure change
        timeO.addListener((obs, oldT, newT) -> {
            SummaryUI summaryUI = summaryUIP.get();
            if (summaryUI != null) {
                Platform.runLater(() -> summaryUI.selectClosestTo(newT));
            }
        });

        Scene scene = new Scene(root);
        primaryStage.setScene(scene);
        primaryStage.setTitle("ReCHor");
        primaryStage.setMinWidth(LARGEUR_MINIMALE);
        primaryStage.setMinHeight(HAUTEUR_MINIMALE);
        primaryStage.show();

        // Focus automatique sur le champ de départ après chargement
        Platform.runLater(() -> scene.lookup("#depStop").requestFocus());
    }

    /**
     * Construit un index des arrêts à partir de la liste des gares et de leurs alias.
     *
     * @param stations les gares de l'horaire.
     * @param aliases les alias des gares.
     * @return l’index des arrêts.
     */
    private static StopIndex buildStopIndex(Stations stations, StationAliases aliases) {
        List<String> stopNames = new ArrayList<>();
        for (int i = 0; i < stations.size(); i++) {
            stopNames.add(stations.name(i));
        }

        Map<String, String> aliasMap = new HashMap<>();
        for (int i = 0; i < aliases.size(); i++) {
            aliasMap.put(aliases.alias(i), aliases.stationName(i));
        }

        return new StopIndex(stopNames, aliasMap);
    }

    /**
     * Retourne l’identifiant (index) de la station portant un nom donné.
     *
     * @param stations les stations.
     * @param name le nom de la station.
     * @return l’identifiant correspondant.
     * @throws IllegalArgumentException si aucune station ne correspond.
     */
    private static int stationId(Stations stations, String name) {
        for (int i = 0; i < stations.size(); i++) {
            if (stations.name(i).equals(name))
                return i;
        }
        throw new IllegalArgumentException("Station inconnue : " + name);
    }

    /**
     * Détermine si la liste de voyages est vide ou nulle.
     *
     * @param journeys la liste à tester.
     * @return vrai si elle est vide ou nulle.
     */
    private static boolean shouldSkip(List<Journey> journeys) {
        return journeys == null || journeys.isEmpty();
    }

    /**
     * Crée une interface divisée en deux parties :
     * la vue d'ensemble des voyages et la vue détaillée du voyage sélectionné.
     *
     * @param journeys les voyages à afficher.
     * @param timeO l’heure de référence.
     * @param summaryUIP propriété dans laquelle est stockée la vue d’ensemble.
     * @param detailUIP propriété dans laquelle est stockée la vue détaillée.
     * @return un composant SplitPane contenant les deux vues.
     */
    private static SplitPane createJourneySplit(List<Journey> journeys,
                                                ObservableValue<java.time.LocalTime> timeO,
                                                ObjectProperty<SummaryUI> summaryUIP,
                                                ObjectProperty<DetailUI> detailUIP) {
        SummaryUI summaryUI = SummaryUI.create(new SimpleObjectProperty<>(journeys), timeO);
        DetailUI detailUI = DetailUI.create(summaryUI.selectedJourney0());
        summaryUIP.set(summaryUI);
        detailUIP.set(detailUI);
        return new SplitPane(summaryUI.rootNode(), detailUI.rootNode());
    }
}